import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AlignJustify, Combine, Eraser, Type, Grid2X2, Plus, X } from "lucide-react";
import type { EditorContext } from "@/components/editor-panels";
import { sidePopoverPlacement } from "@/lib/popover-placement";
import RangeControl from "@/components/range-control";
import TablePaintControl from "@/components/table-paint-control";
import { useLengthUnit } from "@/lib/length-unit";
import { applyTableBorders, applyTableFill, cellSpan, defaultTableBorder, fromDisplayUnit, mergeAt, pxToPt, ptToPx, setTableTrackSize, tableCellFill, tableSelection, tableSize, tableTracks, toDisplayUnit, type BorderLineStyle, type BorderTarget, type TableBorder } from "@/lib/table";

interface Props { ctx: EditorContext }

/** Numeric fields commit on blur/Enter, so clearing a field never changes the design to zero. */
function NumberField({ value, label, min, max, decimals = 1, onCommit, className = "" }: { value: number; label: string; min: number; max: number; decimals?: number; onCommit: (value: number) => void; className?: string }) {
  const display = (n: number) => Number(n.toFixed(decimals)).toString();
  const [draft, setDraft] = useState(display(value));
  const focus = useRef(false);
  useEffect(() => { if (!focus.current) setDraft(display(value)); }, [value, decimals]); // eslint-disable-line react-hooks/exhaustive-deps
  function commit() {
    focus.current = false;
    const n = Number(draft);
    if (draft.trim() && Number.isFinite(n)) { const next = Math.max(min, Math.min(max, n)); onCommit(next); setDraft(display(next)); }
    else setDraft(display(value));
  }
  return <input className={`table-number-input ${className}`} type="number" aria-label={label} value={draft} min={min} max={max} step={decimals ? .1 : 1} onFocus={() => { focus.current = true; }} onChange={e => setDraft(e.target.value)} onBlur={commit} onKeyDown={e => { e.stopPropagation(); if (e.key === "Enter") e.currentTarget.blur(); if (e.key === "Escape") { setDraft(display(value)); e.currentTarget.blur(); } }} />;
}

const targets: { key: BorderTarget; name: string }[] = [
  { key: "all", name: "All borders" }, { key: "outer", name: "Outside borders" }, { key: "inner", name: "Inside borders" },
  { key: "top", name: "Top border" }, { key: "horizontal", name: "Inside horizontal borders" }, { key: "bottom", name: "Bottom border" },
  { key: "left", name: "Left border" }, { key: "vertical", name: "Inside vertical borders" }, { key: "right", name: "Right border" },
];
function BorderIcon({ target }: { target: BorderTarget }) {
  const horizontal = (y: number) => target === "all" || (target === "outer" && y !== 12) || ((target === "inner" || target === "horizontal") && y === 12) || (target === "top" && y === 4) || (target === "bottom" && y === 20);
  const vertical = (x: number) => target === "all" || (target === "outer" && x !== 12) || ((target === "inner" || target === "vertical") && x === 12) || (target === "left" && x === 4) || (target === "right" && x === 20);
  return <svg viewBox="0 0 24 24" width="21" height="21" fill="none" aria-hidden="true"><path d="M4 4H20V20H4ZM12 4V20M4 12H20" stroke="currentColor" opacity=".13" />{[4, 12, 20].map(n => <g key={n}>{horizontal(n) && <path d={`M4 ${n}H20`} stroke="currentColor" strokeWidth="1.8" />}{vertical(n) && <path d={`M${n} 4V20`} stroke="currentColor" strokeWidth="1.8" />}</g>)}</svg>;
}

export default function TableProperties({ ctx }: Props) {
  const layer = ctx.selected!;
  const { rows, cols } = tableSize(layer);
  const trigger = useRef<HTMLButtonElement>(null);
  const [unit] = useLengthUnit(); // shared with the canvas toolbar size fields
  const [target, setTarget] = useState<BorderTarget>("all");
  const [brush, setBrush] = useState<TableBorder>(() => defaultTableBorder(layer));
  const [position, setPosition] = useState({ x: 16, y: 112 });
  const first = ctx.selectedCells[0];
  const selection = tableSelection(layer, ctx.selectedCells);
  const { xs, ys } = tableTracks(layer);
  const span = first ? cellSpan(layer, first.r, first.c) : { rowspan: 1, colspan: 1 };
  const cellWidth = first ? xs[first.c + span.colspan] - xs[first.c] : layer.width / cols;
  const cellHeight = first ? ys[first.r + span.rowspan] - ys[first.r] : layer.height / rows;
  const fill = tableCellFill(layer, first?.r || 0, first?.c || 0);
  const hex = (value: string) => /^#[0-9a-f]{6}$/i.test(value) ? value : "#ffffff";
  const merged = first ? mergeAt(layer, first.r, first.c) : null;

  useEffect(() => {
    if (!ctx.tableStyleOpen) return;
    function place() {
      const rect = trigger.current?.getBoundingClientRect();
      if (rect) { const { left, top } = sidePopoverPlacement(rect, { width: 344, height: 560 }); setPosition({ x: left, y: top }); }
    }
    function outside(event: PointerEvent) { if (!(event.target as Element).closest('[data-table-border-popover],[data-table-style-trigger]')) ctx.setTableStyleOpen(false); }
    function key(event: KeyboardEvent) { if ((event.target as Element).matches?.('input[type="number"]')) return; if (event.key === "Escape") { event.preventDefault(); event.stopImmediatePropagation(); ctx.setTableStyleOpen(false); trigger.current?.focus({ preventScroll: true }); } }
    place();
    document.addEventListener('pointerdown', outside, true);
    document.addEventListener('keydown', key, true);
    window.addEventListener('resize', place);
    document.addEventListener('scroll', place, true);
    return () => { document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', key, true); window.removeEventListener('resize', place); document.removeEventListener('scroll', place, true); };
  }, [ctx.tableStyleOpen, ctx.setTableStyleOpen]);

  function apply(patch: Partial<TableBorder>, chosen = target) {
    const next = { ...brush, ...patch };
    setBrush(next); setTarget(chosen);
    ctx.patch(layer.id, applyTableBorders(layer, ctx.selectedCells, chosen, next));
  }
  const disabled = !!layer.locked;

  return <>
    <span className="context-chip table-chip"><Grid2X2 size={14} />Table</span>
    <button ref={trigger} className={`table-style-trigger ${ctx.tableStyleOpen ? "active" : ""}`} data-table-style-trigger aria-label="Table border and fill" title="Borders & fill" aria-expanded={ctx.tableStyleOpen} onClick={() => ctx.setTableStyleOpen(!ctx.tableStyleOpen)}><AlignJustify size={17} /></button>
    <TablePaintControl ctx={ctx} />
    <button className="context-button" aria-label="Format table cell text" title="Font, size and formatting for the selected cells" disabled={layer.locked} onClick={() => ctx.beginCellText()}><Type size={14} />Text</button>
    <div className="table-track-count"><span>Row</span><NumberField value={rows} label="Table rows" min={1} max={20} decimals={0} onCommit={value => ctx.tableResize(Math.round(value), cols)} /><button disabled={disabled || rows >= 20} aria-label="Add table row" title="Insert a row after selection" onClick={() => ctx.tableInsert("row")}><Plus size={14} /></button></div>
    <div className="table-track-count"><span>Col</span><NumberField value={cols} label="Table columns" min={1} max={12} decimals={0} onCommit={value => ctx.tableResize(rows, Math.round(value))} /><button disabled={disabled || cols >= 12} aria-label="Add table column" title="Insert a column after selection" onClick={() => ctx.tableInsert("column")}><Plus size={14} /></button></div>
    <span className="context-divider" />
    <div className="table-size-field"><span>W</span><NumberField value={toDisplayUnit(cellWidth, unit)} label="Cell width" min={toDisplayUnit(8, unit)} max={toDisplayUnit(10000, unit)} onCommit={value => ctx.patch(layer.id, setTableTrackSize(layer, ctx.selectedCells, "column", fromDisplayUnit(value, unit)))} /><small>{unit}</small></div>
    <div className="table-size-field"><span>H</span><NumberField value={toDisplayUnit(cellHeight, unit)} label="Cell height" min={toDisplayUnit(8, unit)} max={toDisplayUnit(10000, unit)} onCommit={value => ctx.patch(layer.id, setTableTrackSize(layer, ctx.selectedCells, "row", fromDisplayUnit(value, unit)))} /><small>{unit}</small></div>
    <button className="table-compact-action" disabled={disabled || ctx.selectedCells.length < 2} aria-label="Merge selected cells" title="Merge selected cells" onClick={ctx.mergeSelected}><Combine size={15} /></button>
    <button className="table-compact-action" disabled={disabled || !merged} aria-label="Split selected cell" title="Split selected cell" onClick={ctx.splitSelected}><Grid2X2 size={15} /></button>
    <button className="table-clear-button" disabled={disabled} aria-label="Clear table cell contents" title="Clear contents; keep cells and styles" onClick={ctx.tableClear}><Eraser size={14} /><span>Clear</span></button>
    {ctx.tableStyleOpen && createPortal(<div className="table-border-popover" data-table-border-popover role="group" aria-label="Table border controls" style={{ left: position.x, top: position.y, maxHeight: Math.max(150, window.innerHeight - position.y - 12) }}>
      <div className="table-border-heading"><span>{first ? `Selected cells · R${selection.r1 + 1}–${selection.r2 + 1}, C${selection.c1 + 1}–${selection.c2 + 1}` : "Whole table"}</span><button aria-label="Close table border controls" onClick={() => ctx.setTableStyleOpen(false)}><X size={14} /></button></div>
      <div className="table-border-body">
        <div className="table-border-targets" role="group" aria-label="Border placement">{targets.map(item => <button key={item.key} className={target === item.key ? "active" : ""} aria-label={item.name} aria-pressed={target === item.key} title={item.name} disabled={disabled} onClick={() => apply({}, item.key)}><BorderIcon target={item.key} /></button>)}</div>
        <div className="table-border-fields">
          <label>Border color<input type="color" value={hex(brush.color)} aria-label="Table border color" disabled={disabled} onChange={event => apply({ color: event.target.value })} /></label>
          <div className="table-border-width"><label htmlFor="table-border-width">Border width</label><RangeControl compact hideLabel label="Table border width" min={0} max={45} step={.25} value={pxToPt(brush.width)} disabled={disabled} unit="pt" onChange={v => apply({ width: ptToPx(v) })} /></div>
          <label>Fill color<input type="color" value={hex(fill)} aria-label="Table cell fill color" disabled={disabled} onChange={event => ctx.patch(layer.id, applyTableFill(layer, ctx.selectedCells, event.target.value))} /></label>
        </div>
      </div>
      <div className="table-border-styles" role="group" aria-label="Border line style">{(["none", "solid", "dashed", "dotted"] as BorderLineStyle[]).map(style => <button key={style} className={brush.style === style ? "active" : ""} title={`${style} border`} aria-label={`${style[0].toUpperCase() + style.slice(1)} table border`} aria-pressed={brush.style === style} disabled={disabled} onClick={() => apply({ style })}>{style === "none" ? <span>∅</span> : <svg viewBox="0 0 56 14" width="44" height="14" aria-hidden="true"><path d="M5 7H51" stroke="currentColor" strokeWidth="2" strokeDasharray={style === "dashed" ? "7 4" : style === "dotted" ? "1 5" : undefined} strokeLinecap={style === "dotted" ? "round" : "butt"} /></svg>}</button>)}</div>
      <button className="table-transparent-button" aria-label="Make selected cells transparent" onClick={() => ctx.patch(layer.id, applyTableFill(layer, ctx.selectedCells, "transparent"))}><span className="transparency-chip" />No cell fill · Transparent</button>
      <p className="table-border-hint">{first ? "Changes apply to your selected cells." : "Click a cell first to style only that cell."} Shift-click to select more.</p>
    </div>, document.body)}
  </>;
}

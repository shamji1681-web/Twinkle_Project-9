import { useEffect, useRef, useState } from "react";
import { Check, Contact, Eye, EyeOff, Link2, MapPin, Plus, QrCode, Search, Share2, Trash2, Type, Upload, Wifi, X } from "lucide-react";
import {
  BRAND_PREFIX, brandLogoKey, cornerStyles, defaultQRSettings, dotStyles, errorLevels, isBrandLogo,
  normalizeQRSettings, qrPayload, qrPresets, socialUrl,
  validQRContent, type QRContent, type QRCornerStyle, type QRDotStyle, type QRSettings
} from "@/lib/qr";
import { BRAND_LOGOS, brandLogoPng, brandTint } from "@/lib/brand-logos";
import { Spinner } from "@/components/ui";
import RangeControl from "@/components/range-control";
import type { EditorContext } from "@/components/editor-panels";
const MINI_N = 21; // 21 modules — the 1.x QR size, enough to show the styling

/** Deterministic filler pattern so every preview shows the same (stable) code-like grid. */
function miniDark(row: number, col: number) {
  if ((row < 7 && col < 7) || (row < 7 && col >= MINI_N - 7) || (row >= MINI_N - 7 && col < 7)) return false; // finders drawn separately
  if ((row === 7 || col === 7) && (col < 8 || row < 8 || col >= MINI_N - 8 || row >= MINI_N - 8)) return false;
  const v = Math.sin(row * 12.9898 + col * 78.233) * 43758.5453;
  return v - Math.floor(v) > 0.46;
}

/** Draws modules in the chosen dot style; used by both the picker tiles and the hero preview. */
function modulesInStyle(style: QRDotStyle, fg: string) {
  const items: React.ReactNode[] = [];
  const u = 100 / (MINI_N + 4), m = u * 2;
  for (let row = 0; row < MINI_N; row++) {
    for (let col = 0; col < MINI_N; col++) {
      if (!miniDark(row, col)) continue;
      const x = m + col * u, y = m + row * u, cx = x + u / 2, cy = y + u / 2;
      if (style === "dots") items.push(<circle key={`${row}-${col}`} cx={cx} cy={cy} r={u * 0.45} fill={fg} />);
      else if (style === "diamond") items.push(<path key={`${row}-${col}`} d={`M${cx} ${y}L${x + u} ${cy}L${cx} ${y + u}L${x} ${cy}Z`} fill={fg} />);
      else items.push(<rect key={`${row}-${col}`} x={x} y={y} width={u} height={u} rx={style === "rounded" ? u * 0.42 : 0} fill={fg} />);
    }
  }
  return items;
}

function findersInStyle(corner: QRCornerStyle, fg: string) {
  const u = 100 / (MINI_N + 4), m = u * 2;
  const spots: [number, number][] = [[0, 0], [0, MINI_N - 7], [MINI_N - 7, 0]];
  return spots.map(([row, col], index) => {
    const x = m + col * u, y = m + row * u, cx = x + 3.5 * u, cy = y + 3.5 * u;
    if (corner === "circle") return <g key={index}>
      <circle cx={cx} cy={cy} r={3 * u} fill="none" stroke={fg} strokeWidth={u} />
      <circle cx={cx} cy={cy} r={1.5 * u} fill={fg} />
    </g>;
    const outer = corner === "rounded" ? u * 2 : 0;
    const inner = corner === "rounded" ? u * 0.9 : 0;
    return <g key={index}>
      <rect x={x + u / 2} y={y + u / 2} width={6 * u} height={6 * u} rx={outer} fill="none" stroke={fg} strokeWidth={u} />
      <rect x={x + 2 * u} y={y + 2 * u} width={3 * u} height={3 * u} rx={inner} fill={fg} />
    </g>;
  });
}

/** Brand art as an image, with a safe fallback when canvas rendering isn't available. */
function BrandImg({ logoKey, size = 128, fallback }: { logoKey: string; size?: number; fallback?: React.ReactNode }) {
  const url = brandLogoPng(logoKey, size);
  if (url) return <img src={url} alt="" />;
  return <span className="qr-logo-none">{fallback ?? <QrCode size={16} />}</span>;
}

/** A miniature QR that reflects the live dot + corner style, so each option is self-explanatory. */
function MiniQr({ dotStyle, cornerStyle, fg, bg }: { dotStyle: QRDotStyle; cornerStyle: QRCornerStyle; fg: string; bg: string }) {
  return <svg viewBox="0 0 100 100" width="100%" height="100%" aria-hidden="true" className="mini-qr">
    <rect width="100" height="100" rx="6" fill={bg} />
    {findersInStyle(cornerStyle, fg)}
    {modulesInStyle(dotStyle, fg)}
  </svg>;
}

const CONTENT_TYPES = [
  { key: "url", name: "Link", Icon: Link2 },
  { key: "social", name: "Social", Icon: Share2 },
  { key: "location", name: "Location", Icon: MapPin },
  { key: "wifi", name: "Wi‑Fi", Icon: Wifi },
  { key: "vcard", name: "Contact", Icon: Contact },
  { key: "text", name: "Text", Icon: Type },
] as const;

const SOCIAL_PLATFORMS = [
  { key: "instagram", name: "Instagram", placeholder: "username" },
  { key: "whatsapp", name: "WhatsApp", placeholder: "Phone with country code (e.g. 919876543210)" },
  { key: "youtube", name: "YouTube", placeholder: "Channel handle or URL" },
  { key: "telegram", name: "Telegram", placeholder: "username" },
  { key: "twitter", name: "X (Twitter)", placeholder: "username" },
  { key: "facebook", name: "Facebook", placeholder: "page or profile handle" },
  { key: "tiktok", name: "TikTok", placeholder: "username" },
  { key: "linkedin", name: "LinkedIn", placeholder: "profile handle or URL" },
];
const socialBrandColor = (key: string) => brandTint(key);

export function QRPanel({ ctx }: { ctx: EditorContext }) {
  const qrLayer = ctx.selected?.type === "image" && ctx.selected.qr ? ctx.selected : null;
  const [settings, setSettings] = useState<QRSettings>({ ...defaultQRSettings, text: "" });
  const [content, setContent] = useState<QRContent>({ type: "url", value: "https://" });
  const [size, setSize] = useState(0.3);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<"content" | "style">("content");

  // Location search state
  const [showWifiPassword, setShowWifiPassword] = useState(false);
  const [locSearch, setLocSearch] = useState("");
  const [locSearching, setLocSearching] = useState(false);
  const [locResults, setLocResults] = useState<{ name: string; lat: string; lon: string }[]>([]);

  // Logo file upload ref
  const logoInputRef = useRef<HTMLInputElement>(null);

  const update = (patch: Partial<QRSettings>) => setSettings(current => ({ ...current, ...patch }));
  const updateContent = (patch: Partial<QRContent>) => setContent(current => ({ ...current, ...patch }));
  const payloadSettings = (extra: Partial<QRSettings> = {}): QRSettings => ({ ...settings, ...extra, content, text: qrPayload(content) });
  const canScan = validQRContent(content);

  useEffect(() => {
    if (qrLayer?.qr) {
      const normalized = normalizeQRSettings(qrLayer.qr);
      setSettings(normalized);
      setContent(normalized.content || { type: "url", value: normalized.text });
      setPreview(qrLayer.src || null);
      setSize(Number((qrLayer.width / Math.min(ctx.doc.width, ctx.doc.height)).toFixed(2)));
    }
  }, [qrLayer?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  async function refresh(next = payloadSettings()) {
    if (!validQRContent(content)) return;
    setBusy(true);
    const dataUrl = await ctx.previewQR(next);
    setBusy(false);
    if (dataUrl) setPreview(dataUrl);
  }

  // Debounced live preview whenever content or styling changes
  const first = useRef(true);
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    if (!canScan) { setPreview(null); return; }
    const timer = setTimeout(() => void refresh(), 420);
    return () => clearTimeout(timer);
  }, [content, settings]); // eslint-disable-line react-hooks/exhaustive-deps

  /** Puts a built-in logo in the centre and tints the code with its brand colour. */
  function applyBrand(key: string) {
    const colour = socialBrandColor(key);
    update({ customLogo: `${BRAND_PREFIX}${key}`, logo: true, logoScale: 0.23, fg: colour, bg: "#ffffff", transparent: false, gradient: false, errorCorrection: "H" });
  }
  const pickLogo = (key: string) => { key === "none" ? update({ customLogo: null, logo: false }) : applyBrand(key); };
  const changeType = (type: QRContent["type"]) => {
    if (type === "url") applyBrand("web");
    else if (type === "social") applyBrand("instagram");
    else if (type === "wifi") applyBrand("wifi");
    else if (type === "vcard") applyBrand("contact");
    else if (type === "location") applyBrand("location");
    else if (isBrandLogo(settings.customLogo)) update({ customLogo: null, logo: false });
    setContent(
      type === "url" ? { type, value: "https://" }
      : type === "social" ? { type, platform: "instagram", handle: "" }
      : type === "location" ? { type, latitude: "28.6139", longitude: "77.2090" }
      : type === "wifi" ? { type, ssid: "", password: "", encryption: "WPA", hidden: false }
      : type === "vcard" ? { type, firstName: "", lastName: "", phone: "", email: "", organization: "", address: "" }
      : { type, value: "" }
    );
  };

  // Location search using OpenStreetMap Nominatim API
  async function searchLocation(query: string) {
    if (!query.trim()) return;
    setLocSearching(true);
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query.trim())}&limit=5`, {
        headers: { "Accept-Language": "en" }
      });
      const data = await res.json();
      if (Array.isArray(data) && data.length) {
        setLocResults(data.map((item: any) => ({
          name: item.display_name,
          lat: Number(item.lat).toFixed(4),
          lon: Number(item.lon).toFixed(4),
        })));
      } else {
        setLocResults([]);
        ctx.notify("No places found for that search.", true);
      }
    } catch {
      ctx.notify("Location search failed. You can enter coordinates manually.", true);
    } finally {
      setLocSearching(false);
    }
  }

  // Logo upload handler
  function handleLogoUpload(file?: File) {
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
      ctx.notify("Please choose a PNG, JPG or WebP image.", true);
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      ctx.notify("Logo image should be under 2 MB.", true);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      update({ customLogo: dataUrl, logo: true });
      ctx.notify("Logo uploaded! Generating QR with logo in center.");
    };
    reader.onerror = () => ctx.notify("Could not read logo image.", true);
    reader.readAsDataURL(file);
  }

  const activeLogo = settings.customLogo || (settings.logo && ctx.workspace?.logo ? ctx.workspace.logo : null);
  const styleBg = settings.transparent ? "repeating-conic-gradient(#eee 0% 25%, #fff 0% 50%) 50% / 16px 16px" : settings.bg;

  return (
    <div className="qr-panel">
      {/* Live preview */}
      <div className="qr-hero">
        <div className="qr-hero-preview" style={{ background: styleBg }}>
          {preview ? (
            <img src={preview} alt="QR code preview" />
          ) : (
            <span className="qr-hero-empty">
              <QrCode size={30} />
              <small>{canScan ? "Generating preview…" : "Fill in the details below"}</small>
            </span>
          )}
          {busy && <span className="qr-hero-busy"><Spinner size={18} /></span>}
        </div>
        <p className="qr-hero-caption">{qrLayer ? "Editing your QR code" : "Live preview"}</p>
      </div>

      {/* Content / Style tabs */}
      <div className="qr-tabs" role="tablist" aria-label="QR sections">
        <button role="tab" aria-selected={tab === "content"} className={tab === "content" ? "active" : ""} onClick={() => setTab("content")}>Content</button>
        <button role="tab" aria-selected={tab === "style"} className={tab === "style" ? "active" : ""} onClick={() => setTab("style")}>Style & Logo</button>
      </div>

      {/* CONTENT TAB */}
      {tab === "content" && (
        <div className="qr-section">
          {/* Content type picker */}
          <div className="qr-type-grid" role="group" aria-label="QR content type">
            {CONTENT_TYPES.map(({ key, name, Icon }) => (
              <button
                key={key}
                className={content.type === key ? "active" : ""}
                aria-pressed={content.type === key}
                onClick={() => changeType(key)}
              >
                <Icon size={17} />
                <small>{name}</small>
              </button>
            ))}
          </div>

          {/* Website URL */}
          {content.type === "url" && (
            <label className="qr-field">
              Website URL
              <input
                type="url"
                value={content.value || ""}
                maxLength={1200}
                aria-label="QR URL"
                placeholder="https://your-site.com"
                onChange={e => updateContent({ value: e.target.value })}
              />
            </label>
          )}

          {/* Social Media QR */}
          {content.type === "social" && (
            <div className="qr-social-section">
              <span className="qr-field-title">Choose Social Media</span>
              <div className="qr-social-grid">
                {SOCIAL_PLATFORMS.map(({ key, name }) => (
                  <button
                    key={key}
                    type="button"
                    className={`qr-social-btn ${content.platform === key ? "active" : ""}`}
                    onClick={() => { updateContent({ platform: key }); applyBrand(key); }}
                  >
                    <BrandImg logoKey={key} size={96} />
                    <span>{name}</span>
                  </button>
                ))}
              </div>
              {(() => {
                const current = SOCIAL_PLATFORMS.find(p => p.key === (content.platform || "instagram")) || SOCIAL_PLATFORMS[0];
                return (
                  <label className="qr-field" style={{ marginTop: 10 }}>
                    {current.name} username / link
                    <input
                      type="text"
                      value={content.handle || ""}
                      maxLength={200}
                      placeholder={current.placeholder}
                      aria-label={`${current.name} username`}
                      onChange={e => updateContent({ handle: e.target.value })}
                    />
                    {content.handle && (
                      <small className="qr-field-hint">
                        Will open: {socialUrl(content.platform, content.handle)}
                      </small>
                    )}
                    <small className="qr-field-hint">{current.name} logo is placed in the centre of the code automatically — swap it under Style &amp; Logo if you like.</small>
                  </label>
                );
              })()}
            </div>
          )}

          {/* Location with Search */}
          {content.type === "location" && (
            <div className="qr-location-section">
              <span className="qr-field-title">Search Location / Address</span>
              <form
                className="qr-loc-search-row"
                onSubmit={e => { e.preventDefault(); searchLocation(locSearch); }}
              >
                <input
                  type="text"
                  value={locSearch}
                  placeholder="e.g. Connaught Place, Delhi or Paris"
                  aria-label="Search place name"
                  onChange={e => setLocSearch(e.target.value)}
                />
                <button
                  type="submit"
                  className="secondary-button"
                  disabled={locSearching || !locSearch.trim()}
                  title="Search location"
                >
                  {locSearching ? <Spinner size={14} /> : <Search size={14} />}
                </button>
              </form>

              {locResults.length > 0 && (
                <div className="qr-loc-results">
                  <span className="qr-loc-results-title">Search results:</span>
                  {locResults.map((r, i) => (
                    <button
                      key={i}
                      type="button"
                      className="qr-loc-result-item"
                      onClick={() => {
                        updateContent({ latitude: r.lat, longitude: r.lon });
                        setLocResults([]);
                        ctx.notify(`Location set: ${r.name.split(",")[0]}`);
                      }}
                    >
                      <MapPin size={13} />
                      <span className="qr-loc-name">{r.name}</span>
                    </button>
                  ))}
                </div>
              )}

              <span className="qr-field-title" style={{ marginTop: 12 }}>Coordinates</span>
              <div className="qr-fields qr-fields-row">
                <label>
                  Latitude
                  <input
                    aria-label="Location latitude"
                    inputMode="decimal"
                    placeholder="28.6139"
                    value={content.latitude || ""}
                    onChange={e => updateContent({ latitude: e.target.value })}
                  />
                </label>
                <label>
                  Longitude
                  <input
                    aria-label="Location longitude"
                    inputMode="decimal"
                    placeholder="77.2090"
                    value={content.longitude || ""}
                    onChange={e => updateContent({ longitude: e.target.value })}
                  />
                </label>
              </div>
              {(() => {
                const lat = (content.latitude || "").trim(), lng = (content.longitude || "").trim();
                const validLat = /^-?\d{1,2}(\.\d+)?$/.test(lat) && Math.abs(Number(lat)) <= 90;
                const validLng = /^-?\d{1,3}(\.\d+)?$/.test(lng) && Math.abs(Number(lng)) <= 180;
                if (validLat && validLng) return <small className="qr-field-hint qr-hint-ok">
                  ✓ Ready — the code opens {lat}, {lng} in Google Maps.{" "}
                  <a className="qr-map-link" href={`https://www.google.com/maps/search/?api=1&query=${lat},${lng}`} target="_blank" rel="noreferrer">Preview on the map</a>
                </small>;
                return <small className="qr-field-hint qr-hint-warn">Enter coordinates like 28.6139 and 77.2090 (or search above) — the QR code starts working as soon as both are valid.</small>;
              })()}
            </div>
          )}

          {/* Wi-Fi */}
          {content.type === "wifi" && (
            <div className="qr-fields">
              <label>
                Network name (SSID)
                <input
                  aria-label="Wi-Fi network name"
                  value={content.ssid || ""}
                  maxLength={300}
                  placeholder="Home Wi‑Fi"
                  onChange={e => updateContent({ ssid: e.target.value })}
                />
              </label>
              <label>
                Password
                <span className="qr-password-row">
                  <input
                    aria-label="Wi-Fi password"
                    type={showWifiPassword ? "text" : "password"}
                    value={content.password || ""}
                    maxLength={300}
                    placeholder={content.password ? undefined : "Leave blank for an open network"}
                    autoComplete="off"
                    onChange={e => updateContent({ password: e.target.value })}
                  />
                  <button
                    type="button"
                    className="qr-password-toggle"
                    aria-label={showWifiPassword ? "Hide password" : "Show password"}
                    title={showWifiPassword ? "Hide password" : "Show password"}
                    onClick={() => setShowWifiPassword(v => !v)}
                  >
                    {showWifiPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </span>
              </label>
              <small className="qr-field-hint">
                🔒 <strong>Password Protected:</strong> When anyone scans this QR with their camera, phones will show a <strong>"Connect to Wi‑Fi"</strong> button and auto-connect without displaying your plain password on screen!
              </small>
              <div className="qr-fields-row">
                <label>
                  Security
                  <select
                    aria-label="Wi-Fi security"
                    value={content.encryption || "WPA"}
                    onChange={e => updateContent({ encryption: e.target.value as QRContent["encryption"] })}
                  >
                    <option value="WPA">WPA/WPA2</option>
                    <option value="WEP">WEP</option>
                    <option value="nopass">Open</option>
                  </select>
                </label>
                <label className="qr-checkbox">
                  <input
                    aria-label="Hidden Wi-Fi network"
                    type="checkbox"
                    checked={!!content.hidden}
                    onChange={e => updateContent({ hidden: e.target.checked })}
                  />
                  Hidden
                </label>
              </div>
            </div>
          )}

          {/* vCard */}
          {content.type === "vcard" && (
            <div className="qr-fields">
              <div className="qr-fields-row">
                <label>
                  First name
                  <input
                    aria-label="vCard first name"
                    value={content.firstName || ""}
                    maxLength={120}
                    onChange={e => updateContent({ firstName: e.target.value })}
                  />
                </label>
                <label>
                  Last name
                  <input
                    aria-label="vCard last name"
                    value={content.lastName || ""}
                    maxLength={120}
                    onChange={e => updateContent({ lastName: e.target.value })}
                  />
                </label>
              </div>
              <label>
                Organization
                <input
                  aria-label="vCard organization"
                  value={content.organization || ""}
                  maxLength={160}
                  onChange={e => updateContent({ organization: e.target.value })}
                />
              </label>
              <label>
                Phone
                <input
                  aria-label="vCard phone"
                  value={content.phone || ""}
                  maxLength={80}
                  onChange={e => updateContent({ phone: e.target.value })}
                />
              </label>
              <label>
                Email
                <input
                  aria-label="vCard email"
                  type="email"
                  value={content.email || ""}
                  maxLength={120}
                  onChange={e => updateContent({ email: e.target.value })}
                />
              </label>
              <label>
                Address
                <textarea
                  aria-label="vCard address"
                  rows={2}
                  value={content.address || ""}
                  maxLength={300}
                  onChange={e => updateContent({ address: e.target.value })}
                />
              </label>
            </div>
          )}

          {/* Plain text */}
          {content.type === "text" && (
            <label className="qr-field">
              Message
              <textarea
                rows={3}
                value={content.value || ""}
                maxLength={1200}
                aria-label="QR plain text"
                placeholder="Type anything to encode…"
                onChange={e => updateContent({ value: e.target.value })}
              />
            </label>
          )}
        </div>
      )}

      {/* STYLE & LOGO TAB */}
      {tab === "style" && (
        <div className="qr-section">
          {/* Logo upload in center */}
          {/* Logo in the centre — pick a built-in, use the brand kit one, or upload your own */}
          <h3 className="panel-subtitle">Logo in the centre</h3>
          <input
            ref={logoInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            hidden
            onChange={e => { handleLogoUpload(e.target.files?.[0]); e.target.value = ""; }}
          />
          <div className="qr-logo-grid" role="group" aria-label="Choose the centre logo">
            <button type="button" className={`qr-logo-tile ${!activeLogo ? "active" : ""}`} onClick={() => pickLogo("none")} aria-label="No logo">
              <span className="qr-logo-none"><X size={18} /></span>
              <small>None</small>
            </button>
            <button type="button" className={`qr-logo-tile ${settings.customLogo && !isBrandLogo(settings.customLogo) ? "active" : ""}`} onClick={() => logoInputRef.current?.click()} aria-label="Upload a logo">
              <span className="qr-logo-none qr-logo-upload"><Upload size={18} /></span>
              <small>Upload</small>
            </button>
            {ctx.workspace?.logo && (
              <button type="button" className={`qr-logo-tile ${settings.logo && !settings.customLogo ? "active" : ""}`} onClick={() => update({ logo: !settings.logo, customLogo: settings.customLogo || undefined })} aria-label="Use brand kit logo">
                <img src={ctx.workspace.logo} alt="" />
                <small>Brand kit</small>
              </button>
            )}
            {BRAND_LOGOS.map(({ key, name }) => (
              <button
                key={key}
                type="button"
                className={`qr-logo-tile ${isBrandLogo(settings.customLogo) && brandLogoKey(settings.customLogo) === key ? "active" : ""}`}
                onClick={() => pickLogo(key)}
                aria-label={`Use ${name} logo`}
                title={name}
              >
                <BrandImg logoKey={key} size={128} />
                <small>{name}</small>
              </button>
            ))}
          </div>
          {activeLogo ? (
            <>
              <RangeControl
                label="Logo size"
                unit="%"
                min={12}
                max={34}
                value={Math.round((settings.logoScale ?? 0.23) * 100)}
                onChange={v => update({ logoScale: v / 100 })}
              />
              <button type="button" className="secondary-button full-width" onClick={() => pickLogo("none")}><Trash2 size={14} />Remove logo</button>
            </>
          ) : (
            <p className="small-hint">Pick the logo that matches your content type — the code is tinted in that brand's colour and error correction is set to High so it still scans perfectly.</p>
          )}
          {qrPresets.length > 0 && (
            <>
              <h3 className="panel-subtitle">Presets</h3>
              <div className="qr-presets">
                {qrPresets.map(preset => (
                  <button key={preset.name} onClick={() => update(preset.settings)}>
                    {preset.name}
                  </button>
                ))}
              </div>
            </>
          )}

          <h3 className="panel-subtitle">Dot style</h3>
          <div className="qr-style-grid">
            {dotStyles.map(style => (
              <button
                key={style.key}
                className={settings.dotStyle === style.key ? "active" : ""}
                aria-label={`${style.name} dots`}
                onClick={() => update({ dotStyle: style.key })}
              >
                <span className="mini-qr-frame"><MiniQr dotStyle={style.key} cornerStyle={settings.cornerStyle} fg={settings.fg} bg={settings.transparent ? "#f4eff9" : settings.bg} /></span>
                <small>{style.name}</small>
              </button>
            ))}
          </div>

          <h3 className="panel-subtitle">Corner style</h3>
          <div className="qr-style-grid">
            {cornerStyles.map(style => (
              <button
                key={style.key}
                className={settings.cornerStyle === style.key ? "active" : ""}
                aria-label={`${style.name} corners`}
                onClick={() => update({ cornerStyle: style.key })}
              >
                <span className="mini-qr-frame"><MiniQr dotStyle={settings.dotStyle} cornerStyle={style.key} fg={settings.fg} bg={settings.transparent ? "#f4eff9" : settings.bg} /></span>
                <small>{style.name}</small>
              </button>
            ))}
          </div>

          <h3 className="panel-subtitle">Colours</h3>
          <div className="qr-color-row">
            <label className="qr-color">
              <span>Code</span>
              <input
                type="color"
                value={settings.fg}
                aria-label="QR code color"
                onChange={e => update({ fg: e.target.value })}
              />
            </label>
            <label className={`qr-color ${settings.gradient ? "" : "is-disabled"}`}>
              <span>2nd</span>
              <input
                type="color"
                value={settings.fg2}
                disabled={!settings.gradient}
                aria-label="QR gradient second color"
                onChange={e => update({ fg2: e.target.value })}
              />
            </label>
            <label className={`qr-color ${settings.transparent ? "is-disabled" : ""}`}>
              <span>Back</span>
              <input
                type="color"
                value={settings.bg}
                disabled={settings.transparent}
                aria-label="QR background color"
                onChange={e => update({ bg: e.target.value })}
              />
            </label>
          </div>
          <div className="panel-toggle">
            <button
              className={settings.gradient ? "active" : ""}
              onClick={() => update({ gradient: !settings.gradient })}
            >
              Gradient
            </button>
            <button
              className={settings.transparent ? "active" : ""}
              onClick={() => update({ transparent: !settings.transparent })}
            >
              Transparent
            </button>
          </div>

          <h3 className="panel-subtitle">Quiet zone</h3>
          <RangeControl
            label="QR margin"
            unit="px"
            min={0}
            max={8}
            value={settings.margin}
            onChange={margin => update({ margin })}
          />

          <h3 className="panel-subtitle">Error correction</h3>
          <div className="panel-toggle">
            {errorLevels.map(level => (
              <button
                key={level.key}
                className={settings.errorCorrection === level.key ? "active" : ""}
                title={level.note}
                onClick={() => update({ errorCorrection: level.key })}
              >
                {level.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Sticky footer with size + primary action */}
      <div className="qr-footer">
        <div className="qr-size-row">
          <span className="qr-size-label">Size on canvas</span>
          <div className="panel-toggle">
            {([[0.2, "S"], [0.3, "M"], [0.45, "L"]] as [number, string][]).map(([ratio, label]) => (
              <button
                key={label}
                className={size === ratio ? "active" : ""}
                onClick={() => setSize(ratio)}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        {!canScan && <p className="qr-footer-hint">Complete the highlighted fields above to build the code.</p>}
        <button
          className="primary-button full-width"
          disabled={busy || !canScan}
          onClick={async () => {
            const mode = qrLayer ? "update" : "add";
            setBusy(true);
            const ok = await ctx.generateQR(payloadSettings(), mode, size);
            setBusy(false);
            if (ok && !qrLayer) setPreview(null);
          }}
        >
          {busy ? <Spinner /> : qrLayer ? <Check size={17} /> : <Plus size={17} />}
          {busy ? "Styling…" : qrLayer ? "Update QR code" : "Add QR code"}
        </button>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { Check, CloudUpload, Copy, FolderOpen, Pencil, RotateCcw, Save, Search, Star, Trash2, X } from "lucide-react";
import type { DesignProject } from "@/lib/designs";
import DesignCanvas from "@/components/design-canvas";
import { api, EmptyState, Spinner, timeAgo } from "@/components/ui";

interface Props {
  projectId: string;
  title: string;
  status: "saved" | "unsaved" | "saving" | "error";
  /** Bumped by the editor after every successful save so the list refreshes. */
  savedTick: number;
  onSaveNow: () => Promise<boolean>;
  onSaveCopy: () => Promise<DesignProject | null>;
  onOpen: (project: DesignProject) => void;
  notify: (message: string, error?: boolean) => void;
}

export default function ProjectsPanel({ projectId, title, status, savedTick, onSaveNow, onSaveCopy, onOpen, notify }: Props) {
  const [designs, setDesigns] = useState<DesignProject[]>([]);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleting, setDeleting] = useState<string | null>(null);
  const renameRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try { const list = await api<DesignProject[]>("/api/designs"); setDesigns(list.filter(design => !design.trashed)); setFailed(false); }
    catch { setFailed(true); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load, savedTick]);

  useEffect(() => { if (renaming) { renameRef.current?.focus(); renameRef.current?.select(); } }, [renaming]);

  // Only designs the user explicitly saved ever land in this list — nothing else is stored.
  const visible = designs.filter(design => `${design.title} ${design.category}`.toLowerCase().includes(search.trim().toLowerCase()));
  const statusLabel = status === "saving" ? "Saving…" : status === "saved" ? "All changes saved" : status === "error" ? "Last save failed" : "Unsaved changes";

  async function saveNow() {
    setBusy(true);
    const ok = await onSaveNow();
    setBusy(false);
    if (ok) { notify("Saved. This design is in Your projects."); void load(); }
  }

  async function saveCopy() {
    setBusy(true);
    const copy = await onSaveCopy();
    setBusy(false);
    if (copy) { notify(`Saved a copy — “${copy.title}”.`); void load(); }
  }

  async function star(design: DesignProject) {
    try {
      const updated = await api<DesignProject>(`/api/designs/${design.id}`, { method: "PATCH", body: JSON.stringify({ starred: !design.starred }) });
      setDesigns(list => list.map(item => item.id === updated.id ? updated : item));
    } catch (error) { notify((error as Error).message, true); }
  }

  function startRename(design: DesignProject) {
    setDeleting(null);
    setRenaming(design.id);
    setRenameValue(design.title);
  }

  /** Writes the new name; cancels quietly when nothing changed. */
  async function commitRename(design: DesignProject) {
    const next = renameValue.trim();
    setRenaming(null);
    if (!next || next === design.title) return;
    try {
      const updated = await api<DesignProject>(`/api/designs/${design.id}`, { method: "PATCH", body: JSON.stringify({ title: next.slice(0, 120) }) });
      setDesigns(list => list.map(item => item.id === updated.id ? updated : item));
      notify(`Renamed to “${updated.title}”.`);
    } catch (error) { notify((error as Error).message, true); }
  }

  /** Tap once to arm, tap again to move the design out of projects and into Trash. */
  async function remove(design: DesignProject) {
    if (deleting !== design.id) { setRenaming(null); setDeleting(design.id); return; }
    setDeleting(null);
    try {
      await api<DesignProject>(`/api/designs/${design.id}`, { method: "PATCH", body: JSON.stringify({ trashed: true }) });
      setDesigns(list => list.filter(item => item.id !== design.id));
      notify(`“${design.title}” moved to Trash.`);
    } catch (error) { notify((error as Error).message, true); }
  }

  return <>
    <p className="editor-panel-description">Save this design into your projects, and jump between everything you have made.</p>

    <section className={`project-save-card status-${status}`}>
      <div className="project-save-head">
        <span className="project-save-icon">{status === "saving" ? <Spinner size={16} /> : status === "saved" ? <Check size={16} /> : <CloudUpload size={16} />}</span>
        <div><strong>{title.trim() || "Untitled design"}</strong><small>{statusLabel}</small></div>
      </div>
      <div className="project-save-actions">
        <button className="primary-button" disabled={busy || status === "saving"} onClick={() => void saveNow()}>{busy ? <Spinner size={15} /> : <Save size={15} />}Save to projects</button>
        <button className="secondary-button" disabled={busy} onClick={() => void saveCopy()}><Copy size={15} />Save as copy</button>
      </div>
    </section>

    <div className="editor-template-search"><Search size={16} /><input placeholder="Search your projects" value={search} onChange={event => setSearch(event.target.value)} aria-label="Search your projects" /></div>

    <div className="panel-group-heading">
      <h3 className="panel-subtitle">Your projects <span className="count-badge">{designs.length}</span></h3>
      <button className="text-button" onClick={() => void load()} title="Refresh list"><RotateCcw size={13} />Refresh</button>
    </div>

    {loading ? <div className="panel-loading"><Spinner size={20} /></div>
      : failed ? <EmptyState title="Couldn’t load your projects" description="Please try again." action={<button className="secondary-button" onClick={() => void load()}>Try again</button>} />
      : visible.length ? <div className="editor-project-list">
        {visible.map(design => {
          const isCurrent = design.id === projectId;
          const isRenaming = renaming === design.id;
          const isDeleting = deleting === design.id;
          return <article key={design.id} className={`editor-project-card${isCurrent ? " is-current" : ""}${isDeleting ? " is-deleting" : ""}`}>
            <button className="editor-project-thumb" aria-label={`Open ${design.title}`} style={{ background: design.content.background }} disabled={isCurrent} onClick={() => onOpen(design)}>
              <DesignCanvas document={design.content} />
            </button>
            <div className="editor-project-meta">
              {isRenaming ? <div className="editor-project-rename">
                <input
                  ref={renameRef}
                  value={renameValue}
                  maxLength={120}
                  aria-label={`Rename ${design.title}`}
                  onChange={event => setRenameValue(event.target.value)}
                  onBlur={() => void commitRename(design)}
                  onKeyDown={event => {
                    event.stopPropagation();
                    if (event.key === "Enter") { event.preventDefault(); void commitRename(design); }
                    if (event.key === "Escape") { event.preventDefault(); setRenaming(null); }
                  }}
                />
                <button className="icon-button selected" aria-label="Confirm new name" title="Rename" onMouseDown={event => event.preventDefault()} onClick={() => void commitRename(design)}><Check size={14} /></button>
                <button className="icon-button" aria-label="Cancel rename" title="Cancel" onMouseDown={event => event.preventDefault()} onClick={() => setRenaming(null)}><X size={14} /></button>
              </div>
              : <strong title={design.title}>{design.title}</strong>}
              <small>{isCurrent ? "Open now" : `Edited ${timeAgo(design.updatedAt)}`}</small>
              <div className="editor-project-buttons">
                <button className="secondary-button" disabled={isCurrent} onClick={() => onOpen(design)}><FolderOpen size={13} />{isCurrent ? "Current" : "Edit"}</button>
                <button className="icon-button" aria-label={`Rename ${design.title}`} title="Rename" disabled={isRenaming} onClick={() => startRename(design)}><Pencil size={14} /></button>
                <button
                  className={`icon-button ${isDeleting ? "editor-project-delete-armed" : ""}`}
                  aria-label={isDeleting ? `Confirm delete ${design.title}` : `Delete ${design.title}`}
                  aria-pressed={isDeleting}
                  title={isDeleting ? "Tap again to move to Trash" : "Move to Trash"}
                  onClick={() => void remove(design)}
                  onBlur={() => { if (isDeleting) setDeleting(null); }}
                >{isDeleting ? <Check size={14} /> : <Trash2 size={14} />}</button>
                <button className={`icon-button ${design.starred ? "selected" : ""}`} aria-label={design.starred ? `Unstar ${design.title}` : `Star ${design.title}`} title={design.starred ? "Unstar" : "Star"} onClick={() => void star(design)}><Star size={14} fill={design.starred ? "currentColor" : "none"} /></button>
              </div>
            </div>
          </article>;
        })}
      </div>
      : <EmptyState title="Nothing here yet" description="Press “Save to projects” and this design appears in the list." />}
  </>;
}

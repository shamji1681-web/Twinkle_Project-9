import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import type { DesignLayer } from "@/lib/designs";
import { clampLevel, segSizeOf, textLineHeight } from "@/lib/text-fit";
import { toggleScriptRange, type ScriptKind, type ScriptRange } from "@/lib/script-text";
import { autoFormatFractionInText } from "@/lib/fractions";

interface Props {
  layer: DesignLayer;
  scale: number;
  onChange: (text: string) => void;
  onCommit: () => void;
  /** Word's list levels, moved with Tab / Shift+Tab and continued on Enter. */
  onLevels?: (levels: number[]) => void;
  /** Direct patch for list styles, script ranges, etc. */
  onPatch?: (updates: Partial<DesignLayer>) => void;
}

/**
 * The single text edit view: the canvas copy is hidden while editing, so this
 * textarea shows the real readable text (never a transparent caret-only layer,
 * which rendered as double text once the browser painted the selection).
 */
export default function TextEditorOverlay({ layer, scale, onChange, onCommit, onLevels, onPatch }: Props) {
  const ref = useRef<HTMLTextAreaElement>(null);
  const commitRef = useRef(onCommit);
  commitRef.current = onCommit;

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    node.focus({ preventScroll: true });
    node.select();
    function away(event: PointerEvent) {
      const target = event.target as HTMLElement;
      if (node && !node.contains(target) && !target.closest("[data-keep-text-editing]")) commitRef.current();
    }
    const timer = setTimeout(() => document.addEventListener("pointerdown", away), 0);
    return () => { clearTimeout(timer); document.removeEventListener("pointerdown", away); };
  }, [layer.id]);

  const fontSize = segSizeOf(layer, null) * scale;
  const align = layer.align === "justify" || layer.align === "justify-all" ? "justify" : layer.align || "left";
  const ink = layer.textFillTransparent ? (layer.textStrokeColor || layer.fill) : layer.fill;

  function scriptStyle(kind: ScriptKind): CSSProperties {
    const size = Math.max(20, Math.min(100, layer.scriptSize ?? 65)) / 100;
    const shift = Math.max(0, Math.min(400, layer.scriptShift ?? 100)) / 100;
    const parentEm = (kind === "super" ? 0.33 : 0.25) * shift;
    return {
      fontSize: `${size}em`,
      lineHeight: 1,
      position: "relative",
      top: kind === "super" ? `${-parentEm / size}em` : `${parentEm / size}em`,
    };
  }

  function liveRuns(value: string, ranges: ScriptRange[] | undefined, whole?: ScriptKind): ReactNode {
    if (!value) return "\u00a0";
    if (whole) {
      const shift = Math.max(0, Math.min(400, layer.scriptShift ?? 100)) / 100;
      const parentEm = (whole === "super" ? 0.33 : 0.25) * shift;
      return <span style={{ position: "relative", top: whole === "super" ? `${-parentEm}em` : `${parentEm}em` }}>{value}</span>;
    }
    if (!ranges?.length) return value;
    const nodes: ReactNode[] = [];
    let pos = 0;
    const sorted = [...ranges].filter(r => r.start < r.end).sort((a, b) => a.start - b.start);
    sorted.forEach((range, index) => {
      const start = Math.max(pos, Math.min(value.length, range.start));
      const end = Math.max(start, Math.min(value.length, range.end));
      if (start > pos) nodes.push(<span key={`t${index}`}>{value.slice(pos, start)}</span>);
      if (end > start) nodes.push(<span key={`s${index}`} style={scriptStyle(range.kind)}>{value.slice(start, end)}</span>);
      pos = end;
    });
    if (pos < value.length) nodes.push(<span key="tail">{value.slice(pos)}</span>);
    return nodes.length ? nodes : value;
  }

  const paragraphAt = (caret: number) => (layer.text || "").slice(0, caret).split("\n").length - 1;
  const levelAt = (index: number) => clampLevel(layer.paraLevels?.[index]);

  function shiftLevels(from: number, to: number, delta: number) {
    if (!onLevels) return;
    const levels = (layer.paraLevels || []).slice();
    for (let i = from; i <= to; i++) levels[i] = clampLevel(levelAt(i) + delta);
    onLevels(levels);
  }

  /** Word: Enter carries the list level (and the marker) onto the fresh paragraph. */
  function insertParagraph(node: HTMLTextAreaElement) {
    const text = layer.text || "";
    const start = node.selectionStart, end = node.selectionEnd;
    const pi = paragraphAt(start);
    const paragraphs = text.split("\n");
    const currentPara = paragraphs[pi] || "";

    // Word: Pressing Enter on an empty list item exits the list!
    if (layer.listStyle && layer.listStyle !== "none" && !currentPara.trim() && paragraphs.length > 1) {
      const nextLevels = (layer.paraLevels || []).slice();
      if (levelAt(pi) > 0) {
        // Demote level first
        shiftLevels(pi, pi, -1);
        return;
      }
      // If at root level, clear list style if this was the only or last item
      if (paragraphs.length === 1) {
        onPatch?.({ listStyle: undefined, paraLevels: undefined });
        return;
      }
    }

    const next = `${text.slice(0, start)}\n${text.slice(end)}`;
    const levels = (layer.paraLevels || []).slice();
    levels.splice(pi + 1, 0, levelAt(pi));
    onLevels?.(levels);
    onChange(next);
    requestAnimationFrame(() => node.setSelectionRange(start + 1, start + 1));
  }

  function handleTextChange(rawText: string, node: HTMLTextAreaElement) {
    const cursor = node.selectionStart ?? rawText.length;
    const fractionResult = autoFormatFractionInText(rawText, cursor, layer.scriptRanges);
    if (fractionResult) {
      onPatch?.({ text: fractionResult.text, scriptRanges: fractionResult.ranges });
      requestAnimationFrame(() => {
        if (ref.current) {
          ref.current.setSelectionRange(fractionResult.cursor, fractionResult.cursor);
        }
      });
      return;
    }
    onChange(rawText);
  }

  function toggleScript(kind: "sub" | "super", node: HTMLTextAreaElement) {
    const start = node.selectionStart, end = node.selectionEnd;
    const full = layer.text || "";
    if (start >= 0 && end > start) {
      const ranges = toggleScriptRange(full, layer.scriptRanges, start, end, kind);
      onPatch?.({ scriptRanges: ranges.length ? ranges : undefined, script: undefined });
      requestAnimationFrame(() => {
        node.focus();
        node.setSelectionRange(start, end);
      });
      return;
    }
    onPatch?.({ script: layer.script === kind ? undefined : kind, scriptRanges: undefined });
  }

  const typeStyle: CSSProperties = {
    fontSize,
    lineHeight: textLineHeight(layer),
    letterSpacing: (layer.letterSpacing || 0) * scale,
    fontFamily: `${layer.fontFamily || "Arial"}, Arial, sans-serif`,
    fontWeight: layer.fontWeight || 400,
    fontStyle: layer.italic ? "italic" : "normal",
    textAlign: align,
    textAlignLast: layer.align === "justify-all" ? "justify" : undefined,
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
  };

  return <div
    className="text-edit-stack"
    style={{
      left: layer.x * scale,
      top: layer.y * scale,
      width: Math.max(layer.width * scale, fontSize * 0.75),
      height: Math.max(layer.height * scale, fontSize * textLineHeight(layer)),
      transform: `rotate(${layer.rotation || 0}deg)`,
      opacity: layer.opacity ?? 1,
    }}
  >
    <div className="text-edit-live" aria-hidden="true" style={{ ...typeStyle, color: ink, textDecoration: [layer.underline ? "underline" : "", layer.strikethrough ? "line-through" : ""].filter(Boolean).join(" ") || "none", WebkitTextStroke: layer.textStrokeWidth ? `${Math.max(0.5, layer.textStrokeWidth * scale)}px ${layer.textStrokeColor || layer.fill}` : undefined }}>
      {liveRuns(layer.text || "", layer.scriptRanges, layer.script)}
    </div>
    <textarea
    ref={ref}
    className="text-edit-overlay"
    aria-label="Edit text on canvas"
    value={layer.text || ""}
    spellCheck={false}
    onChange={event => handleTextChange(event.target.value, event.target)}
    onPointerDown={event => event.stopPropagation()}
    onDoubleClick={event => event.stopPropagation()}
    onKeyDown={event => {
      event.stopPropagation();
      const node = event.currentTarget;
      const mod = event.metaKey || event.ctrlKey;

      // Word Shortcuts: Ctrl+= for Subscript, Ctrl+Shift+= or Ctrl+. for Superscript
      if (mod && (event.key === "=" || event.key === "+") && event.shiftKey) {
        event.preventDefault();
        toggleScript("super", node);
        return;
      }
      if (mod && (event.key === "=" || event.key === "+") && !event.shiftKey) {
        event.preventDefault();
        toggleScript("sub", node);
        return;
      }
      if (mod && event.key === ".") {
        event.preventDefault();
        toggleScript("super", node);
        return;
      }
      if (mod && event.key === ",") {
        event.preventDefault();
        toggleScript("sub", node);
        return;
      }

      if (event.key === "Escape") { event.preventDefault(); commitRef.current(); return; }
      if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) { event.preventDefault(); commitRef.current(); return; }
      if (event.key === "Enter" && !(event.metaKey || event.ctrlKey) && !(event as unknown as { isComposing?: boolean }).isComposing) {
        event.preventDefault();
        insertParagraph(node);
        return;
      }
      // Word: Tab demotes the list level, Shift+Tab promotes it.
      if (event.key === "Tab") {
        event.preventDefault();
        shiftLevels(paragraphAt(node.selectionStart), paragraphAt(node.selectionEnd), event.shiftKey ? -1 : 1);
        return;
      }
      // Word: Backspace at the very start of an item lifts it one level.
      if (event.key === "Backspace" && node.selectionStart === node.selectionEnd) {
        const caret = node.selectionStart;
        const atStart = caret === 0 || (layer.text || "")[caret - 1] === "\n";
        const index = paragraphAt(caret);
        if (atStart && levelAt(index) > 0) { event.preventDefault(); shiftLevels(index, index, -1); }
      }
    }}
    style={{
      ...typeStyle,
      textDecoration: [layer.underline ? "underline" : "", layer.strikethrough ? "line-through" : ""].filter(Boolean).join(" ") || "none",
      color: "transparent",
      WebkitTextFillColor: "transparent",
      caretColor: "#7c4de0",
      background: "transparent",
    }}
  />
  </div>;
}

import { Eye, RotateCcw, Spline } from "lucide-react";
import RangeControl from "@/components/range-control";
import { ColorField, Swatches, type EditorContext } from "@/components/editor-panels";

/** Text rotation lives in the Effects panel so the topbar stays focused on type basics. */
export function TextRotationControls({ ctx }: { ctx: EditorContext }) {
  const layer = ctx.selected;
  if (!layer || layer.type !== "text") return null;
  return <section className="fx-section">
    <h3 className="panel-subtitle">Text rotation</h3>
    <RangeControl label="Text rotation" min={-360} max={360} value={layer.rotation || 0} unit="°" onChange={v => ctx.patch(layer.id, { rotation: v })} />
  </section>;
}

/** Arcs and circles for the selected text. */
export function TextCurveControls({ ctx }: { ctx: EditorContext }) {
  const layer = ctx.selected;
  if (!layer || layer.type !== "text") return null;
  const curve = layer.curve || 0;
  return <section className="text-curve-section">
    <div className="text-effect-heading"><span><Spline size={16} />Curve</span><button title="Straighten text" aria-label="Reset text curve" onClick={() => ctx.patch(layer.id, { curve: 0 })}><RotateCcw size={14} /></button></div>
    <div className="text-curve-presets">{([{ name: "Straight", value: 0 }, { name: "Upper arc", value: 180 }, { name: "Lower arc", value: -180 }, { name: "Full circle", value: 360 }] as const).map(p => <button key={p.name} className={curve === p.value ? "active" : ""} aria-pressed={curve === p.value} onClick={() => { ctx.stopEditing(); ctx.patch(layer.id, { curve: p.value }); }}>{p.name}</button>)}</div>
    <RangeControl label="Curve text" numberLabel="Curve degrees" min={-360} max={360} value={curve} unit="°" onChange={v => { ctx.stopEditing(); ctx.patch(layer.id, { curve: v }); }} />
    <p className="small-hint">Upper and lower arcs, all the way to a full circle. The frame follows the complete lettering.</p>
  </section>;
}

/** Border around each letter, with its own colour. */
export function TextOutlineControls({ ctx }: { ctx: EditorContext }) {
  const layer = ctx.selected;
  if (!layer || layer.type !== "text") return null;
  return <section className="fx-section text-outline-controls">
    <div className="text-effect-heading"><span><Eye size={16} />Text outline</span><button className={layer.textStrokeWidth ? "active" : ""} aria-label="Toggle text outline" aria-pressed={!!layer.textStrokeWidth} onClick={() => ctx.patch(layer.id, { textStrokeWidth: layer.textStrokeWidth ? 0 : Math.max(2, (layer.fontSize || 40) * .045), textStrokeColor: layer.textStrokeColor || layer.fill })}>{layer.textStrokeWidth ? "On" : "Off"}</button></div>
    <RangeControl label="Text outline width" min={0} max={Math.max(12, Math.round((layer.fontSize || 40) * .3))} step={.25} value={layer.textStrokeWidth || 0} unit="px" onChange={textStrokeWidth => ctx.patch(layer.id, { textStrokeWidth })} />
    <h4 className="fx-color-label">Outline colour</h4>
    <ColorField label="Text outline colour" value={layer.textStrokeColor || layer.fill} onChange={textStrokeColor => ctx.patch(layer.id, { textStrokeColor })} />
    <Swatches ctx={ctx} onPick={textStrokeColor => ctx.patch(layer.id, { textStrokeColor })} />
    <button className={`text-transparent-toggle ${layer.textFillTransparent ? "active" : ""}`} aria-label="Transparent text fill" aria-pressed={!!layer.textFillTransparent} disabled={!layer.textStrokeWidth} onClick={() => ctx.patch(layer.id, { textFillTransparent: !layer.textFillTransparent })}><span className="transparency-chip" />Transparent inside · outline only</button>
    <p className="small-hint">Turn the inner fill transparent to show only the text border. Works with straight and curved text.</p>
  </section>;
}

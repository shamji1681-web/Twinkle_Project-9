import { useEffect, useRef, useState, type PointerEvent } from "react";
import { resolveAsset } from "@/lib/asset-map";
import { Move, Pipette, RotateCcw, X } from "lucide-react";
import RangeControl from "@/components/range-control";
import { gradientCss, gradientStopsOf, type DesignLayer, type GradientFill, type GradientStop } from "@/lib/designs";
import { hexToHsv, hexToRgb, hsvToHex, parseHexInput, PRESET_SWATCHES, rgbToHex, type HSV } from "@/lib/color";
import PhotoGallery from "@/components/photo-gallery";
import { downloadPhoto } from "@/lib/photo-library";

type Tab = "solid" | "linear" | "image";
interface Props {
  layer: DesignLayer;
  brandColors: string[];
  onPatch: (updates: Partial<DesignLayer>) => void;
  onUploadFill: (file: File) => void;
  allowImage?: boolean;
  allowGradient?: boolean;
}

declare global { interface Window { EyeDropper?: new () => { open: () => Promise<{ sRGBHex: string }> } } }

const defaultGradient = (base: string): GradientFill => ({ type: "linear", angle: 135, stops: [{ offset: 0, color: "#1a1a2e", alpha: 1 }, { offset: 0.5, color: base, alpha: 1 }, { offset: 1, color: "#ffffff", alpha: 1 }] });

export default function FillPicker({ layer, brandColors, onPatch, onUploadFill, allowImage = true, allowGradient = true }: Props) {
  const initialTab: Tab = layer.fillImage ? "image" : layer.fillGradient ? "linear" : "solid";
  const [tab, setTab] = useState<Tab>(initialTab);
  const [stopIndex, setStopIndex] = useState(0);
  const [hexInput, setHexInput] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const imagePreviewRef = useRef<HTMLDivElement>(null);
  const imageDrag = useRef<{ x: number; y: number; startX: number; startY: number } | null>(null);
  useEffect(() => setTab(layer.fillImage ? "image" : layer.fillGradient ? "linear" : "solid"), [layer.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const gradient = layer.fillGradient;
  const stops = gradient ? gradientStopsOf(gradient) : [];
  const safeStopIndex = Math.min(stopIndex, Math.max(0, stops.length - 1));
  const activeColor = tab === "linear" && stops.length ? stops[safeStopIndex].color : layer.fill;
  const activeAlpha = tab === "linear" && stops.length ? stops[safeStopIndex].alpha ?? 1 : layer.fillAlpha ?? 1;
  const hsv = hexToHsv(/^#/.test(activeColor) ? activeColor : "#7c4de0");
  useEffect(() => setHexInput(activeColor.replace("#", "").slice(0, 6)), [activeColor]);

  function setColor(hex: string, alpha = activeAlpha) {
    if (tab === "linear" && gradient) {
      const next = stops.map((st, i) => i === safeStopIndex ? { ...st, color: hex, alpha } : st);
      onPatch({ fillGradient: { ...gradient, stops: next }, fillImage: undefined });
    } else {
      onPatch({ fill: hex, fillAlpha: alpha < 1 ? alpha : undefined, fillGradient: undefined, fillImage: undefined });
    }
  }
  function setHsv(next: Partial<HSV>) { setColor(hsvToHex({ ...hsv, ...next })); }
  function setAlpha(alpha: number) { setColor(activeColor, alpha); }

  function switchTab(next: Tab) {
    setTab(next);
    if (next === "solid") onPatch({ fillGradient: undefined, fillImage: undefined });
    if (next === "linear" && !gradient) onPatch({ fillGradient: defaultGradient(layer.fill), fillImage: undefined });
  }

  function updateGradient(patch: Partial<GradientFill>) { if (gradient) onPatch({ fillGradient: { ...gradient, ...patch } }); }
  function setStops(next: GradientStop[]) { updateGradient({ stops: next }); }

  // ---- gradient bar interactions ----
  const barRef = useRef<HTMLDivElement>(null);
  const dragStop = useRef<number | null>(null);
  function barOffset(event: PointerEvent) {
    const rect = barRef.current!.getBoundingClientRect();
    return Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
  }
  function barDown(event: PointerEvent<HTMLDivElement>) {
    if ((event.target as HTMLElement).dataset.stop !== undefined) return;
    const offset = barOffset(event);
    const color = sampleGradient(stops, offset);
    const next = [...stops, { offset, color, alpha: 1 }].sort((a, b) => a.offset - b.offset);
    if (next.length > 8) return;
    setStops(next);
    setStopIndex(next.findIndex(st => st.offset === offset));
  }
  function stopDown(event: PointerEvent<HTMLButtonElement>, index: number) {
    event.stopPropagation();
    event.currentTarget.setPointerCapture(event.pointerId);
    dragStop.current = index;
    setStopIndex(index);
  }
  function stopMove(event: PointerEvent<HTMLButtonElement>) {
    if (dragStop.current === null || !gradient) return;
    const offset = barOffset(event);
    const next = stops.map((st, i) => i === dragStop.current ? { ...st, offset } : st);
    setStops(next);
  }
  function stopUp() {
    if (dragStop.current === null) return;
    const sorted = [...stops].sort((a, b) => a.offset - b.offset);
    const moved = stops[dragStop.current];
    setStops(sorted);
    setStopIndex(Math.max(0, sorted.indexOf(moved)));
    dragStop.current = null;
  }
  function removeStop() {
    if (stops.length <= 2) return;
    const next = stops.filter((_, i) => i !== safeStopIndex);
    setStops(next);
    setStopIndex(Math.max(0, safeStopIndex - 1));
  }

  // ---- SV plane ----
  const planeRef = useRef<HTMLDivElement>(null);
  const planeDrag = useRef(false);
  function planePick(event: PointerEvent) {
    const rect = planeRef.current!.getBoundingClientRect();
    const s = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
    const v = 1 - Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height));
    setHsv({ s, v });
  }

  async function eyedrop() {
    if (!window.EyeDropper) return;
    try { const result = await new window.EyeDropper().open(); setColor(result.sRGBHex.toLowerCase()); } catch { /* cancelled */ }
  }

  const rgb = hexToRgb(activeColor);
  const setChannel = (key: "r" | "g" | "b", value: number) => setColor(rgbToHex({ ...rgb, [key]: Math.max(0, Math.min(255, value)) }));

  return <div className="fill-picker" data-context-popover>
    <div className="fill-tabs" role="tablist">
      {(["solid", ...(allowGradient ? ["linear"] : []), ...(allowImage ? ["image"] : [])] as Tab[]).map(item => <button key={item} role="tab" aria-selected={tab === item} className={tab === item ? "active" : ""} onClick={() => switchTab(item)}>{item === "solid" ? "Solid" : item === "linear" ? "Gradient" : "Image"}</button>)}
    </div>

    {tab === "image" && <div className="fill-image-section">
      <PhotoGallery compact actionLabel="Fill with this photo" onPick={async photo => {
        // Request the photo in the shape of the thing being filled, at a print-friendly size.
        const boost = Math.max(1, 1000 / Math.max(layer.width, layer.height, 1));
        const src = await downloadPhoto(photo, layer.width * boost, layer.height * boost);
        onPatch({ fillImage: src, fillGradient: undefined, fillImageZoom: 1, fillImageX: .5, fillImageY: .5 });
      }} />
      <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={event => { const file = event.target.files?.[0]; if (file) onUploadFill(file); event.target.value = ""; }} />
      <div className="fill-row"><button className="secondary-button" onClick={() => fileRef.current?.click()}>Upload image</button>{layer.fillImage && <button className="secondary-button" onClick={() => onPatch({ fillImage: undefined, fillImageZoom: undefined, fillImageX: undefined, fillImageY: undefined })}><X size={13} />Remove</button>}</div>
      {layer.fillImage && <>
        <div ref={imagePreviewRef} className="fill-image-adjust-preview" role="application" aria-label="Drag image fill to reposition" onPointerDown={event => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); imageDrag.current = { x: event.clientX, y: event.clientY, startX: layer.fillImageX ?? .5, startY: layer.fillImageY ?? .5 }; }} onPointerMove={event => { const d = imageDrag.current, rect = imagePreviewRef.current?.getBoundingClientRect(), zoom = layer.fillImageZoom || 1; if (!d || !rect || zoom <= 1) return; onPatch({ fillImageX: Math.max(0, Math.min(1, d.startX - (event.clientX - d.x) / (rect.width * (zoom - 1)))), fillImageY: Math.max(0, Math.min(1, d.startY - (event.clientY - d.y) / (rect.height * (zoom - 1)))) }); }} onPointerUp={event => { imageDrag.current = null; event.currentTarget.releasePointerCapture?.(event.pointerId); }} onPointerCancel={() => { imageDrag.current = null; }}>
          <img src={resolveAsset(layer.fillImage)} alt="Image fill position preview" draggable={false} style={{ width: `${(layer.fillImageZoom || 1) * 100}%`, height: `${(layer.fillImageZoom || 1) * 100}%`, left: `${-((layer.fillImageZoom || 1) - 1) * (layer.fillImageX ?? .5) * 100}%`, top: `${-((layer.fillImageZoom || 1) - 1) * (layer.fillImageY ?? .5) * 100}%` }} />
          <span><Move size={13} />Drag to reposition</span>
        </div>
        <RangeControl label="Image fill zoom" min={1} max={5} step={.05} value={layer.fillImageZoom || 1} unit="×" onChange={fillImageZoom => onPatch({ fillImageZoom })} />
        <RangeControl label="Image fill horizontal position" min={0} max={100} value={(layer.fillImageX ?? .5) * 100} unit="%" onChange={value => onPatch({ fillImageX: value / 100 })} />
        <RangeControl label="Image fill vertical position" min={0} max={100} value={(layer.fillImageY ?? .5) * 100} unit="%" onChange={value => onPatch({ fillImageY: value / 100 })} />
        <button className="secondary-button full-width" onClick={() => onPatch({ fillImageZoom: 1, fillImageX: .5, fillImageY: .5 })}><RotateCcw size={13} />Reset image position</button>
      </>}
    </div>}

    {tab === "linear" && gradient && <>
      <div className="gradient-bar-wrap">
        <div ref={barRef} className="gradient-bar" style={{ background: gradientCss({ ...gradient, type: "linear", angle: 90 }) }} onPointerDown={barDown} role="slider" aria-label="Gradient stops" aria-valuenow={stops.length}>
          {stops.map((st, i) => <button key={i} data-stop type="button" className={`gradient-stop ${i === safeStopIndex ? "active" : ""}`} style={{ left: `${st.offset * 100}%`, background: st.color }} aria-label={`Gradient stop ${i + 1}`} onPointerDown={event => stopDown(event, i)} onPointerMove={stopMove} onPointerUp={stopUp} onPointerCancel={stopUp} />)}
        </div>
        <div className="fill-row between"><small>Click bar to add stop · drag to move</small><button className="pill-button danger-text" disabled={stops.length <= 2} onClick={removeStop} aria-label="Remove selected stop"><X size={12} />Remove</button></div>
      </div>
      <RangeControl label="Gradient angle" compact min={0} max={360} value={gradient.angle} unit="°" onChange={angle => updateGradient({ angle })} />
      <div className="fill-row between"><span className="fill-label">Stop {safeStopIndex + 1} color</span><div className="stop-chips">{stops.map((st, i) => <button key={i} className={i === safeStopIndex ? "active" : ""} style={{ background: st.color }} aria-label={`Select stop ${i + 1}`} onClick={() => setStopIndex(i)} />)}</div></div>
      <div className="fill-row"><span className="fill-label">Type</span><div className="panel-toggle compact"><button className={gradient.type === "linear" ? "active" : ""} onClick={() => updateGradient({ type: "linear" })}>Linear</button><button className={gradient.type === "radial" ? "active" : ""} onClick={() => updateGradient({ type: "radial" })}>Radial</button></div></div>
    </>}

    {tab !== "image" && <>
      <div ref={planeRef} className="sv-plane" style={{ background: `linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, ${hsvToHex({ h: hsv.h, s: 1, v: 1 })})` }} role="slider" aria-label="Saturation and brightness" aria-valuenow={Math.round(hsv.v * 100)}
        onPointerDown={event => { planeDrag.current = true; (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId); planePick(event); }}
        onPointerMove={event => { if (planeDrag.current) planePick(event); }}
        onPointerUp={() => { planeDrag.current = false; }}
        onPointerCancel={() => { planeDrag.current = false; }}>
        <span className="sv-cursor" style={{ left: `${hsv.s * 100}%`, top: `${(1 - hsv.v) * 100}%` }} />
      </div>
      <RangeControl label="Hue" hideLabel sliderClassName="hue-slider" min={0} max={360} value={Math.round(hsv.h)} unit="°" onChange={h => setHsv({ h })} />
      <RangeControl label="Alpha" hideLabel className="alpha-range-control" sliderClassName="alpha-slider" sliderStyle={{ background: `linear-gradient(to right, transparent, ${activeColor})` }} min={0} max={100} value={Math.round(activeAlpha * 100)} unit="%" onChange={v => setAlpha(v / 100)} />

      <div className="fill-row"><span className="fill-preview" style={{ background: activeColor, opacity: activeAlpha }} /><button className="secondary-button" onClick={() => void eyedrop()} disabled={typeof window === "undefined" || !window.EyeDropper} title={typeof window !== "undefined" && window.EyeDropper ? "Pick a colour from the screen" : "Eyedropper needs Chrome or Edge"}><Pipette size={13} />Pick</button></div>

      <div className="fill-inputs">
        <label><input value={hexInput} aria-label="Hex" onChange={event => { setHexInput(event.target.value); const parsed = parseHexInput(event.target.value); if (parsed) setColor(parsed); }} maxLength={7} /><span>Hex</span></label>
        <label><input type="number" min={0} max={255} value={rgb.r} aria-label="Red" onChange={event => setChannel("r", Number(event.target.value))} /><span>R</span></label>
        <label><input type="number" min={0} max={255} value={rgb.g} aria-label="Green" onChange={event => setChannel("g", Number(event.target.value))} /><span>G</span></label>
        <label><input type="number" min={0} max={255} value={rgb.b} aria-label="Blue" onChange={event => setChannel("b", Number(event.target.value))} /><span>B</span></label>
        <label><input type="number" min={0} max={100} value={Math.round(activeAlpha * 100)} aria-label="Alpha percent" onChange={event => setAlpha(Math.max(0, Math.min(100, Number(event.target.value))) / 100)} /><span>A</span></label>
      </div>

      <div className="swatch-grid">{PRESET_SWATCHES.map(color => <button key={color} style={{ background: color }} aria-label={`Use ${color}`} title={color} className={activeColor === color ? "active" : ""} onClick={() => setColor(color)} />)}</div>
    </>}
  </div>;
}

function sampleGradient(stops: GradientStop[], offset: number) {
  if (!stops.length) return "#7c4de0";
  const sorted = [...stops].sort((a, b) => a.offset - b.offset);
  let before = sorted[0], after = sorted[sorted.length - 1];
  for (const st of sorted) { if (st.offset <= offset) before = st; if (st.offset >= offset) { after = st; break; } }
  if (before === after || after.offset === before.offset) return before.color;
  const t = (offset - before.offset) / (after.offset - before.offset);
  const a = hexToRgb(before.color), b = hexToRgb(after.color);
  return rgbToHex({ r: a.r + (b.r - a.r) * t, g: a.g + (b.g - a.g) * t, b: a.b + (b.b - a.b) * t });
}

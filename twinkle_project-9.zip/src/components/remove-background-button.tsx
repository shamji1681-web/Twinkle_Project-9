import { useEffect, useRef, useState } from "react";
import { Eraser, RotateCcw, X } from "lucide-react";
import type { EditorContext } from "./editor-panels";
import { Spinner } from "./ui";
import { removeBackgroundWithBounds, type BackgroundRemovalProgress } from "@/lib/remove-background";
import { canTrimLayerToSubject, trimBox, untrimBox } from "@/lib/cutout-geometry";

export default function RemoveBackgroundButton({ ctx }: { ctx: EditorContext }) {
  const [progress, setProgress] = useState<BackgroundRemovalProgress | null>(null);
  const job = useRef<AbortController | null>(null);
  const mounted = useRef(true);
  const latest = useRef(ctx);
  latest.current = ctx;

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      // Changing selection must not apply a pending cutout to another layer.
      job.current?.abort();
    };
  }, []);

  async function remove() {
    const layer = latest.current.selected;
    if (job.current || layer?.type !== "image" || layer.qr || layer.locked || !layer.src || layer.originalSrc) return;
    const id = layer.id;
    const src = layer.src;
    const controller = new AbortController();
    job.current = controller;
    setProgress({ stage: "preparing", message: "Preparing the photo" });
    try {
      const result = await removeBackgroundWithBounds(src, {
        signal: controller.signal,
        // Shrink the layer to the subject when its frame shows the whole photo 1:1 (otherwise keep the frame).
        trim: (frameWidth, frameHeight) => {
          const live = latest.current.doc.layers.find(item => item.id === id);
          return !!live && canTrimLayerToSubject(live, frameWidth, frameHeight);
        },
        onProgress: next => {
          if (mounted.current && !controller.signal.aborted) setProgress(next);
        },
      });
      if (!mounted.current || controller.signal.aborted) return;
      const currentLayer = latest.current.doc.layers.find(item => item.id === id);
      if (currentLayer?.type !== "image" || currentLayer.src !== src || currentLayer.locked || currentLayer.qr) {
        latest.current.notify("The image changed during processing. Its current version was kept.", true);
        return;
      }
      if (result.crop && !canTrimLayerToSubject(currentLayer, result.frameWidth, result.frameHeight)) {
        latest.current.notify("The image was resized or cropped during processing. Its current version was kept.", true);
        return;
      }
      latest.current.patch(id, {
        src: result.dataUrl,
        originalSrc: src,
        ...(result.crop ? { ...trimBox(currentLayer, result.crop), cutoutCrop: result.crop } : {}),
      });
      latest.current.notify("Background removed. Restore BG or Undo brings the original back.");
    } catch (error) {
      if (!mounted.current) return;
      if (controller.signal.aborted) latest.current.notify("Background removal cancelled. Original photo kept.");
      else latest.current.notify(error instanceof Error ? error.message : "Could not remove the background. Please retry.", true);
    } finally {
      if (job.current === controller) job.current = null;
      if (mounted.current) setProgress(null);
    }
  }

  const layer = ctx.selected;
  if (layer?.type !== "image" || layer.qr) return null;
  const progressLabel = !progress ? "Remove BG"
    : progress.stage === "loading" ? `Loading AI${progress.percent === undefined ? "" : ` ${progress.percent}%`}`
    : progress.stage === "preparing" ? "Preparing photo"
    : progress.stage === "refining" ? "Refining edges"
    : progress.stage === "encoding" ? "Creating PNG" : "Removing BG";

  return <span className="bg-removal-actions" role="group" aria-label="Photo background">
    {layer.originalSrc
      ? <button type="button" className="context-button" disabled={!!layer.locked || !!progress} aria-label="Restore original background" title="Restore the original image; you can then run Remove BG again" onClick={() => {
          if (!layer.originalSrc || layer.locked) return;
          ctx.patch(layer.id, { src: layer.originalSrc, originalSrc: undefined, cutoutCrop: undefined, ...(layer.cutoutCrop ? untrimBox(layer, layer.cutoutCrop) : {}) });
          ctx.notify("Original background restored.");
        }}><RotateCcw size={14} />Restore BG</button>
      : <button type="button" className="context-button remove-bg-topbar" disabled={!!progress || !layer.src || !!layer.locked} aria-label="Remove image background" aria-busy={!!progress} title={progress?.message || "Remove the photo background. Photos stay on your device."} onClick={() => void remove()}>
          {progress ? <Spinner size={14} /> : <Eraser size={14} />}{progressLabel}
        </button>}
    {progress && <button type="button" className="context-icon" aria-label="Cancel background removal" title="Cancel background removal" onClick={() => job.current?.abort()}><X size={14} /></button>}
    <span className="sr-only" role="status" aria-live="polite">{progress ? `${progress.message}${progress.percent === undefined ? "" : `: ${progress.percent}%`}` : ""}</span>
  </span>;
}
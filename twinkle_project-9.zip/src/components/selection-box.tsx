import { useRef, useState, type PointerEvent } from "react";
import { RotateCw } from "lucide-react";
import type { DesignLayer } from "@/lib/designs";
import { outlineBleed } from "@/components/design-canvas";
import { minimumTextWidth, wrappedTextHeight } from "@/lib/text-fit";
import { isCurvedText, resizeCurvedText } from "@/lib/text-curve";

interface Props {
  layer: DesignLayer;
  scale: number;
  onChange: (updates: Partial<DesignLayer>) => void;
  onStart: () => void;
  onEnd: () => void;
  onShiftClick?: (id: string) => void;
}

const HANDLES = [
  { key: "nw", ax: -1, ay: -1, name: "top left", cursor: "nwse-resize" },
  { key: "n", ax: 0, ay: -1, name: "top", cursor: "ns-resize" },
  { key: "ne", ax: 1, ay: -1, name: "top right", cursor: "nesw-resize" },
  { key: "e", ax: 1, ay: 0, name: "right", cursor: "ew-resize" },
  { key: "se", ax: 1, ay: 1, name: "bottom right", cursor: "nwse-resize" },
  { key: "s", ax: 0, ay: 1, name: "bottom", cursor: "ns-resize" },
  { key: "sw", ax: -1, ay: 1, name: "bottom left", cursor: "nesw-resize" },
  { key: "w", ax: -1, ay: 0, name: "left", cursor: "ew-resize" },
] as const;

const MIN = 8;
const rotate = (x: number, y: number, radians: number) => ({ x: x * Math.cos(radians) - y * Math.sin(radians), y: x * Math.sin(radians) + y * Math.cos(radians) });

export default function SelectionBox({ layer, scale, onChange, onStart, onEnd, onShiftClick }: Props) {
  const boxRef = useRef<HTMLDivElement>(null);
  const state = useRef<{ mode: "resize" | "rotate"; handle: string; ax: number; ay: number; startX: number; startY: number; layer: DesignLayer; centerX: number; centerY: number; startAngle: number } | null>(null);
  const [active, setActive] = useState<"resize" | "rotate" | null>(null);
  const [activeHandle, setActiveHandle] = useState<string | null>(null);
  const [live, setLive] = useState<{ width: number; height: number; rotation: number }>({ width: layer.width, height: layer.height, rotation: layer.rotation || 0 });

  const angle = layer.rotation || 0;
  const radians = angle * Math.PI / 180;
  // An Effects-panel outline paints outside the layer's own box — further on sharp shapes
  // than round ones — so the frame grows by exactly the same amount the canvas draws.
  const bleed = outlineBleed(layer) * scale;
  const width = layer.width * scale + bleed * 2;
  const height = layer.height * scale + bleed * 2;
  const keepRatio = layer.type === "image" || layer.type === "icon" || layer.type === "draw";
  // Icons and QR codes must stay square-ish: only the four corner handles scale them,
  // so the edge handles (which stretch one axis) are hidden for these layers.
  const cornersOnly = layer.type === "icon" || (layer.type === "image" && !!layer.qr);
  const handles = cornersOnly ? HANDLES.filter(handle => handle.ax !== 0 && handle.ay !== 0) : HANDLES;

  function begin(event: PointerEvent<HTMLElement>, mode: "resize" | "rotate", handleKey: string, ax = 0, ay = 0) {
    if ((event as unknown as Event & { shiftKey?: boolean }).shiftKey) {
      // SelectionBox sits above the canvas surface; Shift+click on the layer body still
      // needs to feed the multi-select bridge — the canvas hook handles it.
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    const rect = boxRef.current!.getBoundingClientRect();
    state.current = { mode, handle: handleKey, ax, ay, startX: event.clientX, startY: event.clientY, layer: { ...layer }, centerX: rect.left + rect.width / 2, centerY: rect.top + rect.height / 2, startAngle: Math.atan2(event.clientY - (rect.top + rect.height / 2), event.clientX - (rect.left + rect.width / 2)) };
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    setActive(mode);
    setActiveHandle(handleKey);
    setLive({ width: layer.width, height: layer.height, rotation: angle });
    onStart();
  }

  function move(event: PointerEvent<HTMLElement>) {
    const drag = state.current;
    if (!drag) return;
    const source = drag.layer;

    if (drag.mode === "rotate") {
      const pointer = Math.atan2(event.clientY - drag.centerY, event.clientX - drag.centerX);
      let next = (source.rotation || 0) + (pointer - drag.startAngle) * 180 / Math.PI;
      next = ((next % 360) + 360) % 360;
      if (next > 180) next -= 360;
      if (event.shiftKey) next = Math.round(next / 15) * 15;
      else for (const snap of [-180, -90, 0, 90, 180]) if (Math.abs(next - snap) < 4) next = snap;
      const rounded = Math.round(next);
      setLive({ width: source.width, height: source.height, rotation: rounded });
      onChange({ rotation: rounded });
      return;
    }

    const dx = (event.clientX - drag.startX) / scale;
    const dy = (event.clientY - drag.startY) / scale;
    const local = rotate(dx, dy, -(source.rotation || 0) * Math.PI / 180);
    let nextWidth = drag.ax ? Math.max(MIN, source.width + local.x * drag.ax) : source.width;
    let nextHeight = drag.ay ? Math.max(MIN, source.height + local.y * drag.ay) : source.height;

    const corner = drag.ax !== 0 && drag.ay !== 0;
    const horizontalEdge = drag.ax !== 0 && drag.ay === 0;
    const verticalEdge = drag.ax === 0 && drag.ay !== 0;
    if (isCurvedText(source)) {
      const factor = corner
        ? (source.width * nextWidth + source.height * nextHeight) / (source.width ** 2 + source.height ** 2)
        : drag.ax ? nextWidth / source.width : nextHeight / source.height;
      const updates = resizeCurvedText(source, factor, drag.ax, drag.ay);
      setLive({ width: updates.width!, height: updates.height!, rotation: source.rotation || 0 });
      onChange(updates);
      return;
    }
    if (corner && (event.shiftKey || keepRatio) && !event.altKey) {
      const ratio = source.width / source.height;
      if (Math.abs(nextWidth / source.width - 1) > Math.abs(nextHeight / source.height - 1)) nextHeight = Math.max(MIN, nextWidth / ratio);
      else nextWidth = Math.max(MIN, nextHeight * ratio);
    }

    // Text boxes never clip their words:
    //  - side handles (horizontal edge, incl. middle left/right) reflow the words
    //    into a narrower column and the height follows — even when that column
    //    becomes a tall single-word line.
    //  - top/bottom handles (vertical edge, incl. bottom-center) clamp the height
    //    to the minimum that still fits the full wrapped content.
    // The measuring layer always pretends to be a fixed frame (autoFit off), because
    // an auto-fit hug box skips wrapping and would report a single-line height —
    // which is exactly what let words spill outside the shrinking box.
    const isText = source.type === "text";
    const wrapText = isText && horizontalEdge;
    if (isText && (wrapText || verticalEdge)) {
      // Keep shrinking until a one-character column, but never below the
      // widest glyph/marker/drop-cap advance. This prevents the last visible
      // character from painting outside the selection frame.
      if (wrapText) nextWidth = Math.max(nextWidth, minimumTextWidth(source));
      const contentHeight = wrappedTextHeight(
        { ...source, width: nextWidth, autoFit: false },
        nextWidth
      );
      if (verticalEdge) {
        nextHeight = Math.max(nextHeight, contentHeight);
      } else {
        nextHeight = Math.max(contentHeight, MIN);
      }
    }

    const centerX = source.x + source.width / 2, centerY = source.y + source.height / 2;
    const anchor = { x: -drag.ax, y: -drag.ay };
    const before = rotate(anchor.x * source.width / 2, anchor.y * source.height / 2, radians);
    const after = rotate(anchor.x * nextWidth / 2, anchor.y * nextHeight / 2, radians);
    const nextCenterX = centerX + before.x - after.x;
    const nextCenterY = centerY + before.y - after.y;

    const updates: Partial<DesignLayer> = {
      width: Math.round(nextWidth), height: Math.round(nextHeight),
      x: Math.round(nextCenterX - nextWidth / 2), y: Math.round(nextCenterY - nextHeight / 2),
    };
    if (source.type === "text" && corner && source.fontSize) updates.fontSize = Math.max(8, Math.min(1000, Math.round(source.fontSize * nextHeight / source.height)));
    // A side-resize turns the box into a fixed frame, so the canvas wraps words
    // into the new width instead of hugging a single unwrapped line.
    if (source.type === "text" && (wrapText || verticalEdge)) updates.autoFit = false;
    if (source.type === "stroke" && source.strokeWidth && drag.ay) updates.strokeWidth = Math.max(1, Math.min(400, Math.round(source.strokeWidth * nextHeight / source.height)));
    setLive({ width: updates.width!, height: updates.height!, rotation: source.rotation || 0 });
    onChange(updates);
  }

  function finish(event: PointerEvent<HTMLElement>) {
    if (!state.current) return;
    (event.currentTarget as HTMLElement).releasePointerCapture?.(event.pointerId);
    state.current = null;
    setActive(null);
    setActiveHandle(null);
    onEnd();
  }

  const isDragging = !!active;

  return <div ref={boxRef} className={`selection-box ${active ? "is-active" : ""} ${isDragging ? "is-dragging" : ""}`} data-selection-box="true" style={{ left: layer.x * scale - bleed, top: layer.y * scale - bleed, width, height, transform: `rotate(${angle}deg)` }} onPointerDown={event => {
    // The box sits above the canvas: Shift+click on the selected layer itself must
    // still reach multi-select (toggle off) instead of starting a drag/resize.
    if (event.shiftKey && onShiftClick && (event.target as HTMLElement).closest("[data-selection-box]")) {
      onShiftClick(layer.id);
      event.preventDefault();
      event.stopPropagation();
    }
  }}>
    <div className="selection-outline" />
    {handles.map(handle => {
      const isThis = activeHandle === handle.key;
      const hide = isDragging && !isThis;
      return <button
        key={handle.key}
        type="button"
        className={`selection-handle handle-${handle.key} ${handle.ax === 0 || handle.ay === 0 ? "handle-edge" : "handle-corner"}${isThis ? " is-active-handle" : ""}${hide ? " is-hidden-handle" : ""}`}
        style={{ cursor: handle.cursor, left: `${(handle.ax + 1) * 50}%`, top: `${(handle.ay + 1) * 50}%` }}
        aria-label={`Resize from ${handle.name}`}
        aria-hidden={hide || undefined}
        tabIndex={hide ? -1 : undefined}
        onPointerDown={event => begin(event, "resize", handle.key, handle.ax, handle.ay)}
        onPointerMove={move}
        onPointerUp={finish}
        onPointerCancel={finish}
      />;
    })}
    <button
      type="button"
      className={`selection-rotate${activeHandle === "rotate" ? " is-active-handle" : ""}${isDragging && activeHandle !== "rotate" ? " is-hidden-handle" : ""}`}
      aria-label="Rotate element"
      aria-hidden={isDragging && activeHandle !== "rotate" ? true : undefined}
      tabIndex={isDragging && activeHandle !== "rotate" ? -1 : undefined}
      style={{ cursor: active === "rotate" ? "grabbing" : "grab" }}
      onPointerDown={event => begin(event, "rotate", "rotate")}
      onPointerMove={move}
      onPointerUp={finish}
      onPointerCancel={finish}
    ><RotateCw size={13} /></button>
    {active && layer.type !== "table" && <span className="selection-readout" style={{ transform: `rotate(${-angle}deg)` }}>{active === "rotate" ? `${live.rotation}°` : `${live.width} × ${live.height}`}</span>}
  </div>;
}

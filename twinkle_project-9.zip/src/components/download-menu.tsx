import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronDown, Download, FileImage, FileText, Image as ImageIcon, Layers, LoaderCircle, X } from "lucide-react";
import type { DesignDocument } from "@/lib/designs";
import { exportDesign, type ExportFormat } from "@/lib/export";
import RangeControl from "@/components/range-control";

interface Props {
  doc: DesignDocument;
  title: string;
  save: () => Promise<boolean>;
  notify: (message: string, error?: boolean) => void;
}

const details: Record<ExportFormat, { label: string; note: string; icon: typeof FileImage; long: string }> = {
  jpeg: { label: "JPEG", note: "Small, photo-friendly · white background", icon: ImageIcon, long: "JPEG" },
  png: { label: "PNG", note: "Transparent, high quality pixels", icon: FileImage, long: "PNG" },
  pdf: { label: "PDF", note: "Print-ready vector document", icon: FileText, long: "PDF Vector" },
  svg: { label: "SVG", note: "Editable vector artwork", icon: FileText, long: "SVG" },
};
const resolutions = [
  { value: 1, label: "1×", hint: "Screen" },
  { value: 2, label: "2×", hint: "Retina" },
  { value: 3, label: "3×", hint: "Print" },
];

export default function DownloadMenu({ doc, title, save, notify }: Props) {
  const [open, setOpen] = useState(false);
  const [format, setFormat] = useState<ExportFormat>("jpeg");
  const [quality, setQuality] = useState(92);
  const [scale, setScale] = useState(1);
  const [vectorPdf, setVectorPdf] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [position, setPosition] = useState({ left: 12, top: 68 });
  const trigger = useRef<HTMLButtonElement>(null);
  const menu = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (!open) return;
    function place() {
      const rect = trigger.current?.getBoundingClientRect();
      if (!rect) return;
      const width = 300;
      // Download always opens directly beneath its header button on desktop.
      // It is a bottom drawer only on phone-sized layouts (CSS media rule).
      setPosition({ left: Math.max(10, Math.min(rect.right - width, window.innerWidth - width - 10)), top: rect.bottom + 7 });
    }
    place(); window.addEventListener("resize", place); document.addEventListener("scroll", place, true);
    return () => { window.removeEventListener("resize", place); document.removeEventListener("scroll", place, true); };
  }, [open, format]);

  useEffect(() => {
    if (!open) return;
    function outside(event: PointerEvent) { if (!menu.current?.contains(event.target as Node) && !trigger.current?.contains(event.target as Node)) setOpen(false); }
    function key(event: KeyboardEvent) { if (event.key === "Escape") { event.preventDefault(); setOpen(false); trigger.current?.focus(); } }
    document.addEventListener("pointerdown", outside, true); document.addEventListener("keydown", key, true);
    return () => { document.removeEventListener("pointerdown", outside, true); document.removeEventListener("keydown", key, true); };
  }, [open]);

  async function run() {
    setExporting(true);
    try {
      if (!(await save())) throw new Error("Save your design before downloading.");
      const result = await exportDesign(doc, title, format, { jpegQuality: quality / 100, rasterScale: scale, vectorPdf });
      setOpen(false);
      notify(result.message);
    } catch (error) { notify((error as Error).message, true); }
    finally { setExporting(false); }
  }

  const Icon = details[format].icon;
  const rasterSize = format === "svg" ? null : `${Math.round(doc.width * scale)} × ${Math.round(doc.height * scale)} px`;

  return <>
    <button ref={trigger} className={`editor-download ${open ? "is-open" : ""}`} aria-label="Download" aria-expanded={open} onClick={() => setOpen(!open)}><Download size={17} /><span>Download</span><ChevronDown size={14} /></button>
    {open && createPortal(<div ref={menu} className="download-popover" data-download-popover role="dialog" aria-label="Download your design" style={{ left: position.left, top: position.top }}>
      <div className="download-popover-heading"><span className="download-heading-icon"><Icon size={16} /></span><div><strong>Download</strong><small>{doc.width} × {doc.height} px · {details[format].label}</small></div><button aria-label="Close download menu" onClick={() => setOpen(false)}><X size={16} /></button></div>
      <span className="download-type-label" id="download-file-type">File type</span>
      <div className="download-type-grid" role="radiogroup" aria-labelledby="download-file-type">
        {(Object.keys(details) as ExportFormat[]).map(key => {
          const Tile = details[key].icon;
          return <button key={key} type="button" role="radio" aria-checked={format === key} className={`download-type-tile ${format === key ? "is-active" : ""}`} onClick={() => setFormat(key)}><Tile size={16} /><span>{details[key].label}</span></button>;
        })}
      </div>
      <p className="download-format-note">{details[format].note}{rasterSize ? ` · ${rasterSize}` : ""}</p>

      {(format === "png" || format === "jpeg") && <>
        <span className="download-type-label" id="download-resolution">Resolution</span>
        <div className="download-type-grid is-three" role="radiogroup" aria-labelledby="download-resolution">
          {resolutions.map(option => <button key={option.value} type="button" role="radio" aria-checked={scale === option.value} className={`download-type-tile is-compact ${scale === option.value ? "is-active" : ""}`} onClick={() => setScale(option.value)}><span className="download-tile-stack"><strong>{option.label}</strong><em>{option.hint}</em></span></button>)}
        </div>
      </>}

      {format === "jpeg" && <RangeControl label="Quality" value={quality} min={10} max={100} unit="%" onChange={setQuality} />}

      {format === "pdf" && <>
        <label className="download-option">
          <input type="checkbox" checked={vectorPdf} onChange={event => setVectorPdf(event.target.checked)} />
          <span><strong>Keep vector artwork</strong><small>Text, shapes, gradients and photos stay sharp; only soft shadows, masks and image fills are placed as high-resolution layers.</small></span>
        </label>
        <p className="download-tip">{vectorPdf
          ? "Vector PDF: text stays selectable and curves stay crisp at any zoom or print size."
          : "Flat PDF: the whole page is embedded as one image — maximum compatibility, no selectable text."}</p>
      </>}

      {format === "svg" && <p className="download-tip"><Layers size={11} /> Fully editable vector file with images and uploaded fonts embedded, so it opens correctly in Illustrator, Figma, Inkscape and browsers.</p>}

      <button className="download-action" disabled={exporting} onClick={() => void run()}>{exporting ? <LoaderCircle className="spinner" size={17} /> : <Download size={17} />}{exporting ? "Preparing…" : `Download ${details[format].long}`}</button>
    </div>, document.body)}
  </>;
}

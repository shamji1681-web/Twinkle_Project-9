import { useId, useRef, useState, type PointerEvent, type ReactNode } from "react";
import { resolveAsset } from "@/lib/asset-map";
import { gradientStops, gradientStopsOf, hasEffects, hexWithAlpha, isGradient, type DesignDocument, type DesignLayer, type LayerEffects } from "@/lib/designs";
import { DEFAULT_SHAPE_MITER, shapeByKey } from "@/lib/shapes";
import OpacityFadeMask from "@/components/opacity-fade-mask";
import { listedLines, measureTextWidth, textLineHeight, wrapString } from "@/lib/text-fit";
import { typesetText } from "@/lib/typeset";
import { curvedGlyphs, curveBounds, normalizeCurvedLayer } from "@/lib/text-curve";
import { cellIndex, cellSpan, tableBorderSegments, tableCellFill, tableCellGradient, tableCellTextColor, tableTracks, visibleCells } from "@/lib/table";
export { tableTracks } from "@/lib/table";
import { layoutCellText } from "@/lib/table-text";
import type { CellRef } from "@/lib/table";

export interface Guide { axis: "x" | "y"; at: number }

interface Props {
  document: DesignDocument;
  className?: string;
  interactive?: boolean;
  drawMode?: boolean;
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
  /** Toggle multi-select when Shift is held while clicking a token. */
  onMultiSelect?: (id: string) => void;
  /** Double-click a grouped layer to edit just that member. */
  onDrillDown?: (id: string) => void;
  /** Rubber-band select: ids intersecting the marquee (additive when Shift held). */
  onMarqueeSelect?: (ids: string[], additive: boolean) => void;
  onLayerChange?: (id: string, updates: Partial<DesignLayer>) => void;
  onInteractionStart?: () => void;
  onInteractionEnd?: () => void;
  onGuides?: (guides: Guide[]) => void;
  onHover?: (id: string | null) => void;
  onTextActivate?: (id: string) => void;
  editingId?: string | null;
  editingTableCell?: (CellRef & { layerId: string }) | null;
}

function flowerPath(width: number, height: number) {
  const points: string[] = [];
  for (let i = 0; i <= 160; i++) {
    const a = i / 160 * Math.PI * 2;
    const r = .365 + .12 * Math.cos(8 * a);
    points.push(`${width / 2 + Math.cos(a) * width * r},${height / 2 + Math.sin(a) * height * r}`);
  }
  return `M${points.join(" L")} Z`;
}

function patternTile(pattern: string, color: string, t: number): ReactNode {
  const w = Math.max(1, t * .04);
  switch (pattern) {
    case "grid": return <path d={`M${t} 0H0V${t}`} fill="none" stroke={color} strokeWidth={w} />;
    case "stripes": return <path d={`M0 ${t} L${t} 0 M${-t * .3} ${t * .3} L${t * .3} ${-t * .3} M${t * .7} ${t * 1.3} L${t * 1.3} ${t * .7}`} fill="none" stroke={color} strokeWidth={t * .13} />;
    case "checks": return <><rect width={t / 2} height={t / 2} fill={color} /><rect x={t / 2} y={t / 2} width={t / 2} height={t / 2} fill={color} /></>;
    case "waves": return <path d={`M0 ${t * .72} Q${t * .25} ${t * .34} ${t * .5} ${t * .72} T${t} ${t * .72}`} fill="none" stroke={color} strokeWidth={t * .09} strokeLinecap="round" />;
    case "confetti": return <><circle cx={t * .24} cy={t * .28} r={t * .07} fill={color} /><rect x={t * .62} y={t * .18} width={t * .2} height={t * .07} rx={t * .035} fill={color} transform={`rotate(28 ${t * .72} ${t * .21})`} /><rect x={t * .18} y={t * .68} width={t * .2} height={t * .07} rx={t * .035} fill={color} transform={`rotate(-24 ${t * .28} ${t * .71})`} /><circle cx={t * .74} cy={t * .74} r={t * .05} fill={color} /></>;
    default: return <circle cx={t / 2} cy={t / 2} r={t * .11} fill={color} />;
  }
}

function strokeContent(layer: DesignLayer, w: number, h: number): ReactNode {
  const sw = layer.strokeWidth ?? Math.max(2, h * .3);
  const mid = h / 2;
  const base = { stroke: layer.fill, fill: "none", strokeLinecap: "round" as const };
  const v = layer.variant || "solid";
  // Page borders: drawn inset by half the stroke so nothing is clipped at the canvas edge.
  if (v.startsWith("border-")) {
    const i = sw / 2, bw = Math.max(0, w - sw), bh = Math.max(0, h - sw);
    const rect = (extra: Record<string, unknown> = {}) => <rect x={i} y={i} width={bw} height={bh} {...base} strokeLinejoin="round" strokeWidth={sw} {...extra} />;
    if (v === "border-rounded") return rect({ rx: Math.min(bw, bh) * .06 + sw });
    if (v === "border-dashed") return rect({ strokeDasharray: `${sw * 4} ${sw * 3}` });
    if (v === "border-dotted") return rect({ strokeDasharray: `0.01 ${sw * 2.6}` });
    if (v === "border-double") { const g = sw * 2.2; return <g>{rect()}<rect x={i + g} y={i + g} width={Math.max(0, bw - g * 2)} height={Math.max(0, bh - g * 2)} {...base} strokeLinejoin="round" strokeWidth={sw * .5} /></g>; }
    if (v === "border-inset") { const g = sw * 3; return <g>{rect({ strokeWidth: sw * .5 })}<rect x={i + g} y={i + g} width={Math.max(0, bw - g * 2)} height={Math.max(0, bh - g * 2)} {...base} strokeLinejoin="round" strokeWidth={sw} /></g>; }
    return rect();
  }
  // Page corners: an L-shaped ornament drawn in the top-left; rotation places it in other corners.
  if (v.startsWith("corner-")) {
    const i = sw / 2, L = Math.max(2, Math.min(w, h) - sw), k = L / 100;
    // Ornament art is authored in a 0–100 unit box, then scaled into the layer.
    const box = (kids: ReactNode, weight = sw) => (
      <g transform={`translate(${i} ${i}) scale(${k})`} fill="none" stroke={layer.fill} strokeLinecap="round" strokeLinejoin="round" strokeWidth={weight / k}>{kids}</g>
    );
    const thin = sw * .5 / k, mid = sw * .75 / k, dot = { fill: layer.fill, stroke: "none" } as const;
    switch (v) {
      case "corner-round": return box(<path d="M0 100V20A20 20 0 0 1 20 0H100" />);
      case "corner-double": return box(<><path d="M0 100V0H100" /><path d="M16 86V16H86" strokeWidth={thin} /></>);
      case "corner-bracket": return box(<path d="M0 55V0H55" />);
      case "corner-flourish": return box(<><path d="M0 100V0H100" strokeWidth={mid} /><circle cx="13" cy="13" r="9" {...dot} /><path d="M34 20q10 14 26 2" strokeWidth={thin} /></>);
      case "corner-grid": return box(<><path d="M0 100V0H100" strokeWidth={mid} /><rect x="2" y="2" width="22" height="22" /><rect x="28" y="2" width="22" height="22" /><rect x="2" y="28" width="22" height="22" /><rect x="28" y="28" width="22" height="22" /></>);
      case "corner-boxline": return box(<><rect x="2" y="2" width="17" height="17" /><path d="M10 100V10H100" /><path d="M24 88V24H88" strokeWidth={thin} /></>);
      case "corner-arrow": return box(<><rect x="1" y="1" width="13" height="13" {...dot} /><path d="M7 100V7H84" /><path d="M84 0l16 7-16 7z" {...dot} /></>);
      case "corner-leaf": return box(<><path d="M10 94V14H86" strokeWidth={mid} /><path d="M10 94c-8-9-8-19 0-26 8 7 8 17 0 26z" {...dot} /><path d="M86 14c8 4 8 12 0 16-8-4-8-12 0-16z" {...dot} /></>);
      case "corner-vine": return box(<><path d="M6 100V22q0-16 16-16h70" strokeWidth={mid} /><path d="M6 50q16-12 28 2" strokeWidth={thin} /><path d="M44 6q12-9 20 3" strokeWidth={thin} /><circle cx="30" cy="40" r="4.5" {...dot} /></>);
      case "corner-curl": return box(<path d="M0 100V28q0-18 18-18q15 0 15 12q0 11-11 11q-8 0-8-7" strokeWidth={mid} />);
      case "corner-scroll": return box(<><path d="M4 100V30q0-26 26-26h64" strokeWidth={mid} /><path d="M4 64q18-16 34 0q14 14 32-6" strokeWidth={thin} /><circle cx="4" cy="30" r="5.5" {...dot} /></>);
      case "corner-star": return box(<><path d="M0 100V10H88" /><path d="M14 90V14H88" strokeWidth={thin} /><path d="M95 2l2.9 6.1 6.6.9-4.8 4.6 1.2 6.5-5.9-3.2-5.9 3.2 1.2-6.5-4.8-4.6 6.6-.9z" {...dot} /></>);
      case "corner-diamond": return box(<><path d="M0 100V0H100" strokeWidth={mid} /><path d="M22 0v14" strokeWidth={thin} /><path d="M22 14l9 11-9 11-9-11z" /><path d="M0 30h14" strokeWidth={thin} /><path d="M48 0v9" strokeWidth={thin} /><path d="M48 9l7 9-7 9-7-9z" /></>);
      case "corner-bow": return box(<><path d="M0 100V0H100" strokeWidth={mid} /><path d="M24 8q-16-13-19 3 11 9 19-3z" {...dot} /><path d="M24 8q16-13 19 3-11 9-19-3z" {...dot} /><circle cx="24" cy="9" r="4" /></>);
      case "corner-shield": return box(<><path d="M0 100V0H100" strokeWidth={mid} /><path d="M0 100l26-26" strokeWidth={thin} /><path d="M26 74l-9-9 9-9 9 9z" /><rect x="4" y="46" width="10" height="10" /></>);
      case "corner-nested": return box(<><rect x="1" y="1" width="34" height="34" /><rect x="10" y="10" width="16" height="16" strokeWidth={thin} /><path d="M35 8H100" /><path d="M8 35V100" /></>);
      default: return box(<path d="M0 100V0H100" />);
    }
  }
  switch (v) {
    case "double": return <g><line x1={0} y1={mid - sw} x2={w} y2={mid - sw} {...base} strokeWidth={sw * .55} /><line x1={0} y1={mid + sw} x2={w} y2={mid + sw} {...base} strokeWidth={sw * .55} /></g>;
    case "arrow": { const end = Math.max(0, w - sw * 2.6); return <g><line x1={0} y1={mid} x2={end} y2={mid} {...base} strokeWidth={sw} /><path d={`M${end} ${mid - sw * 2} L${w} ${mid} L${end} ${mid + sw * 2} Z`} fill={layer.fill} /></g>; }
    case "wave": { const amp = Math.min(mid * .75, sw * 2.2), step = w / 4; let d = `M0 ${mid}`; for (let i = 0; i < 4; i++) d += ` q${step / 2} ${i % 2 ? amp * 2 : -amp * 2} ${step} 0`; return <path d={d} {...base} strokeWidth={sw} />; }
    case "zigzag": { const amp = Math.min(mid * .85, sw * 2.6), step = w / 6; let d = `M0 ${mid}`; for (let i = 0; i < 6; i++) d += ` L${(step * (i + .5)).toFixed(1)} ${i % 2 ? mid + amp : mid - amp} L${(step * (i + 1)).toFixed(1)} ${mid}`; return <path d={d} {...base} strokeWidth={sw} strokeLinejoin="round" />; }
    case "dashed": return <line x1={0} y1={mid} x2={w} y2={mid} {...base} strokeWidth={sw} strokeDasharray={`${sw * 4} ${sw * 3}`} />;
    case "dotted": return <line x1={0} y1={mid} x2={w} y2={mid} {...base} strokeWidth={sw} strokeDasharray={`0.01 ${sw * 2.6}`} />;
    default: return <line x1={0} y1={mid} x2={w} y2={mid} {...base} strokeWidth={sw} />;
  }
}

function tableContent(layer: DesignLayer, width: number, height: number, uid: string, editingCell?: CellRef | null): ReactNode {
  const { rows, cols, xs, ys } = tableTracks(layer, width, height);
  const line = layer.lineColor || layer.fill;
  const lw = layer.lineWidth ?? Math.max(1, Math.min(width / cols, height / rows) * .028);
  const cells = layer.cells ?? [];
  return <g>
    <rect width={width} height={height} fill="transparent" />
    {visibleCells(layer).map(({ r, c }) => {
      const { rowspan, colspan } = cellSpan(layer, r, c);
      const x = xs[c], y = ys[r], w = xs[c + colspan] - xs[c], h = ys[r + rowspan] - ys[r];
      const header = r === 0 && layer.headerFill;
      const gradient = tableCellGradient(layer, r, c), paintId = `${uid}-cell-fill-${r}-${c}`;
      const cellPaint = gradient ? `url(#${paintId})` : tableCellFill(layer, r, c);
      const textColor = tableCellTextColor(layer, r, c);
      return <g key={`${r}-${c}`} data-table-cell={`${r}:${c}`}>
        {gradient && <defs>{gradient.type === "radial"
          ? <radialGradient id={paintId} cx="50%" cy="50%" r="70%">{gradientStopsOf(gradient).map((st, i) => <stop key={i} offset={st.offset} stopColor={st.color} stopOpacity={st.alpha ?? 1} />)}</radialGradient>
          : <linearGradient id={paintId} gradientTransform={`rotate(${gradient.angle - 90} 0.5 0.5)`}>{gradientStopsOf(gradient).map((st, i) => <stop key={i} offset={st.offset} stopColor={st.color} stopOpacity={st.alpha ?? 1} />)}</linearGradient>}
        </defs>}
        <rect x={x} y={y} width={w} height={h} fill={cellPaint} />
        {cells[cellIndex(cols, r, c)] && !(editingCell?.r === r && editingCell.c === c) ? (() => {
          const layout = layoutCellText(layer, r, c, w, h);
          const textX = x + (layout.align === "left" ? layout.padX : layout.align === "right" ? w - layout.padX : w / 2);
          const cellClipId = `${uid}-cell-${r}-${c}`;
          return <g key={`txt-${r}-${c}`} clipPath={`url(#${cellClipId})`}>
            <defs><clipPath id={cellClipId}><rect x={x + 2} y={y + 2} width={Math.max(1, w - 4)} height={Math.max(1, h - 4)} /></clipPath></defs>
            {layout.lines.map((lineText, li) => <text key={li} x={textX} y={y + layout.top + li * layout.fontSize * layout.lineHeight + layout.fontSize * .84} fontSize={layout.fontSize} fill={textColor} fontFamily={layout.fontFamily} fontWeight={layout.fontWeight} fontStyle={layout.italic ? "italic" : "normal"} letterSpacing={layout.letterSpacing} textDecoration={[layout.underline ? "underline" : "", layout.strikethrough ? "line-through" : ""].filter(Boolean).join(" ") || undefined} textAnchor={layout.align === "left" ? "start" : layout.align === "right" ? "end" : "middle"}>{lineText}</text>)}
          </g>;
        })() : null}
      </g>;
    })}
    <g data-table-borders="true">{tableBorderSegments(layer, width, height).map(({ key, x1, y1, x2, y2, border }) => {
      if (!(border.width > 0 && border.style !== "none")) return null;
      // Strokes are centred on the grid line, so ends that stop exactly at the
      // table outline leave an empty half-width square in each corner. Extend
      // those ends so perpendicular outer borders meet flush.
      const half = border.width / 2;
      const horizontal = y1 === y2;
      const ex1 = horizontal && x1 <= 0 ? x1 - half : x1;
      const ex2 = horizontal && x2 >= width ? x2 + half : x2;
      const ey1 = !horizontal && y1 <= 0 ? y1 - half : y1;
      const ey2 = !horizontal && y2 >= height ? y2 + half : y2;
      return <line key={key} data-table-edge={key} x1={ex1} y1={ey1} x2={ex2} y2={ey2} stroke={border.color} strokeWidth={border.width} strokeDasharray={border.style === "dashed" ? `${border.width * 4} ${border.width * 2.5}` : border.style === "dotted" ? `0.01 ${border.width * 2.5}` : undefined} strokeLinecap={border.style === "dotted" ? "round" : "butt"} />;
    })}</g>
  </g>;
}

function paint(layer: DesignLayer, uid: string, width: number, height: number): { fill: string; defs: ReactNode; opacity?: number } {
  if (layer.fillImage) {
    const zoom = Math.max(1, Math.min(5, layer.fillImageZoom || 1));
    const imageWidth = width * zoom, imageHeight = height * zoom;
    const x = -(imageWidth - width) * Math.max(0, Math.min(1, layer.fillImageX ?? .5));
    const y = -(imageHeight - height) * Math.max(0, Math.min(1, layer.fillImageY ?? .5));
    return { fill: `url(#${uid}-imgfill)`, defs: <pattern id={`${uid}-imgfill`} patternUnits="userSpaceOnUse" width={width} height={height}><rect width={width} height={height} fill="transparent"/><image href={resolveAsset(layer.fillImage)} x={x} y={y} width={imageWidth} height={imageHeight} preserveAspectRatio="xMidYMid slice" /></pattern> };
  }
  if (layer.fillGradient) {
    const g = layer.fillGradient;
    const stops = gradientStopsOf(g).map((st, i) => <stop key={i} offset={`${st.offset * 100}%`} stopColor={st.color} stopOpacity={st.alpha ?? 1} />);
    if (g.type === "radial") return { fill: `url(#${uid}-grad)`, defs: <radialGradient id={`${uid}-grad`} cx="50%" cy="50%" r="70%">{stops}</radialGradient> };
    return { fill: `url(#${uid}-grad)`, defs: <linearGradient id={`${uid}-grad`} gradientTransform={`rotate(${g.angle - 90} 0.5 0.5)`}>{stops}</linearGradient> };
  }
  const alpha = layer.fillAlpha ?? 1;
  return { fill: alpha < 1 ? hexWithAlpha(layer.fill, alpha) : layer.fill, defs: null };
}

function maskPath(mask: string | undefined, width: number, height: number, radius = 0): ReactNode {
  const clampedRadius = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
  const fullCircle = (!mask || mask === "none") && clampedRadius >= Math.min(width, height) / 2 - 0.5;
  if (fullCircle || mask === "circle") return <ellipse cx={width / 2} cy={height / 2} rx={width / 2} ry={height / 2} />;
  if (!mask || mask === "none") return <rect width={width} height={height} rx={clampedRadius} />;
  if (mask === "rounded") return <rect width={width} height={height} rx={Math.max(clampedRadius, Math.min(width, height) * .18)} />;
  const key = mask === "star" ? "star5" : mask;
  const asset = shapeByKey(key);
  if (!asset) return <rect width={width} height={height} />;
  return <g transform={`scale(${width / 100} ${height / 100})`}><path d={asset.d} fillRule={asset.evenOdd ? "evenodd" : "nonzero"} /></g>;
}

function photoContent(layer: DesignLayer, uid: string, width: number, height: number): ReactNode {
  const hasErase = !!layer.erased?.length;
  const natW = hasErase && layer.naturalWidth ? layer.naturalWidth : width;
  const natH = hasErase && layer.naturalHeight ? layer.naturalHeight : height;
  const zoom = Math.max(1, layer.cropZoom || 1);
  const imgW = natW * zoom, imgH = natH * zoom;
  const ox = -((layer.cropX || 0) * Math.max(0, imgW - natW));
  const oy = -((layer.cropY || 0) * Math.max(0, imgH - natH));
  const scaleTransform = natW !== width || natH !== height ? `scale(${width / Math.max(1, natW)} ${height / Math.max(1, natH)})` : undefined;
  return <g transform={scaleTransform}>
    <defs><clipPath id={uid} clipPathUnits="userSpaceOnUse">{maskPath(layer.mask, natW, natH, layer.radius || 0)}</clipPath></defs>
    <g clipPath={`url(#${uid})`}><image href={resolveAsset(layer.src)} x={ox} y={oy} width={imgW} height={imgH} preserveAspectRatio="xMidYMid slice" /></g>
  </g>;
}

/** Builds every effect as SVG filter primitives so canvas, PNG and SVG exports all match. */
function effectFilter(id: string, fx: LayerEffects, skipOutline = false): ReactNode {
  const parts: ReactNode[] = [];
  let graphic = "SourceGraphic";
  const step = (node: ReactNode) => { parts.push(node); };

  // Colour adjustments run on the graphic first.
  if (fx.brightness !== undefined && fx.brightness !== 1) {
    step(<feComponentTransfer key="br" in={graphic} result="br"><feFuncR type="linear" slope={fx.brightness} /><feFuncG type="linear" slope={fx.brightness} /><feFuncB type="linear" slope={fx.brightness} /></feComponentTransfer>); graphic = "br";
  }
  if (fx.contrast !== undefined && fx.contrast !== 1) {
    const c = fx.contrast, i = 0.5 - 0.5 * c;
    step(<feComponentTransfer key="ct" in={graphic} result="ct"><feFuncR type="linear" slope={c} intercept={i} /><feFuncG type="linear" slope={c} intercept={i} /><feFuncB type="linear" slope={c} intercept={i} /></feComponentTransfer>); graphic = "ct";
  }
  if (fx.saturation !== undefined && fx.saturation !== 1) { step(<feColorMatrix key="sa" in={graphic} type="saturate" values={String(fx.saturation)} result="sa" />); graphic = "sa"; }
  if (fx.grayscale) { step(<feColorMatrix key="gr" in={graphic} type="saturate" values={String(1 - fx.grayscale)} result="gr" />); graphic = "gr"; }
  if (fx.sepia) {
    const a = fx.sepia, m = [0.393, 0.769, 0.189, 0.349, 0.686, 0.168, 0.272, 0.534, 0.131];
    const mix = (sep: number, idn: number) => (sep * a + idn * (1 - a)).toFixed(3);
    const values = [mix(m[0], 1), mix(m[1], 0), mix(m[2], 0), 0, 0, mix(m[3], 0), mix(m[4], 1), mix(m[5], 0), 0, 0, mix(m[6], 0), mix(m[7], 0), mix(m[8], 1), 0, 0, 0, 0, 0, 1, 0].join(" ");
    step(<feColorMatrix key="se" in={graphic} type="matrix" values={values} result="se" />); graphic = "se";
  }
  if (fx.blur) { step(<feGaussianBlur key="bl" in={graphic} stdDeviation={fx.blur} result="bl" />); graphic = "bl"; }

  // Layers behind the graphic, back to front.
  const behind: string[] = [];
  if (fx.shadow) {
    step(<feGaussianBlur key="s1" in="SourceAlpha" stdDeviation={fx.shadow.blur} result="shadowBlur" />);
    step(<feOffset key="s2" in="shadowBlur" dx={fx.shadow.x} dy={fx.shadow.y} result="shadowOffset" />);
    step(<feFlood key="s3" floodColor={fx.shadow.color} floodOpacity={fx.shadow.opacity} result="shadowColor" />);
    step(<feComposite key="s4" in="shadowColor" in2="shadowOffset" operator="in" result="shadow" />);
    behind.push("shadow");
  }
  if (fx.glow) {
    step(<feMorphology key="g0" in="SourceAlpha" operator="dilate" radius={Math.max(1, fx.glow.blur / 3)} result="glowBase" />);
    step(<feGaussianBlur key="g1" in="glowBase" stdDeviation={fx.glow.blur} result="glowBlur" />);
    step(<feFlood key="g2" floodColor={fx.glow.color} floodOpacity={fx.glow.opacity} result="glowColor" />);
    step(<feComposite key="g3" in="glowColor" in2="glowBlur" operator="in" result="glow" />);
    behind.push("glow");
  }
  if (!skipOutline && fx.outline && fx.outline.width > 0) {
    const w = fx.outline.width;
    // Dilate alone leaves a hard, stair-stepped edge (very visible on text).
    // A small blur rounds the outer rim so the stroke looks soft and clean.
    const smooth = Math.min(2.5, Math.max(0.6, w * 0.22));
    step(<feMorphology key="o1" in="SourceAlpha" operator="dilate" radius={w} result="dilated" />);
    step(<feGaussianBlur key="o1s" in="dilated" stdDeviation={smooth} result="dilatedSmooth" />);
    step(<feFlood key="o2" floodColor={fx.outline.color} result="outlineColor" />);
    step(<feComposite key="o3" in="outlineColor" in2="dilatedSmooth" operator="in" result="outline" />);
    behind.push("outline");
  }

  const pad = 40 + (fx.shadow ? fx.shadow.blur * 3 + Math.max(Math.abs(fx.shadow.x), Math.abs(fx.shadow.y)) : 0) + (fx.glow ? fx.glow.blur * 4 : 0) + (fx.outline?.width || 0) * 2 + (fx.blur || 0) * 3;
  return <filter id={id} x={`-${pad}%`} y={`-${pad}%`} width={`${100 + pad * 2}%`} height={`${100 + pad * 2}%`} colorInterpolationFilters="sRGB" filterUnits="objectBoundingBox">
    {parts}
    <feMerge>{[...behind, graphic].map(name => <feMergeNode key={name} in={name} />)}</feMerge>
  </filter>;
}

/**
 * How far an Effects-panel outline paints past the layer's own box, in canvas units.
 * Sharp vertices reach further than round ones, so each shape carries its own miter
 * factor — the selection frame and hit test use this same number, which is why the
 * box always hugs exactly what you see.
 */
export function outlineBleed(layer: DesignLayer): number {
  const width = layer.effects?.outline?.width || 0;
  if (width <= 0) return 0;
  if (layer.type === "shape") return width * (shapeByKey(layer.shape)?.miter ?? DEFAULT_SHAPE_MITER);
  if (layer.type === "star") return width * 2.2;
  if (layer.type === "icon") return width * 1.6;
  if (layer.type === "rect") return width * (layer.radius ? 1.05 : 1);
  return width;
}

export function layerContainsPoint(layer: DesignLayer, px: number, py: number, pad = 0) {
  const cx = layer.x + layer.width / 2, cy = layer.y + layer.height / 2;
  const angle = -(layer.rotation || 0) * Math.PI / 180;
  const dx = px - cx, dy = py - cy;
  const localX = dx * Math.cos(angle) - dy * Math.sin(angle);
  const localY = dx * Math.sin(angle) + dy * Math.cos(angle);
  const extraOutline = outlineBleed(layer);
  return Math.abs(localX) <= layer.width / 2 + pad + extraOutline && Math.abs(localY) <= layer.height / 2 + pad + extraOutline;
}

/** Topmost selectable layer under a canvas point, or null for empty canvas. */
export function topLayerAt(doc: DesignDocument, px: number, py: number, pad: number, forText = false) {
  return [...doc.layers].reverse().find(layer => {
    if (layer.hidden) return false;
    if (forText && layer.type !== "text") return false;
    return layerContainsPoint(layer, px, py, pad);
  }) || null;
}

/** Layers that overlap a click, ordered back-to-front by selection depth (Shift+click choice). */
export function candidateLayersAt(doc: DesignDocument, px: number, py: number, pad: number): DesignLayer[] {
  return doc.layers.filter(layer => !layer.hidden && !layer.locked && layerContainsPoint(layer, px, py, pad)).reverse();
}

/** Snaps a moving layer to canvas and sibling edges, returning the adjusted position and guides. */
function snapPosition(layer: DesignLayer, x: number, y: number, doc: DesignDocument, tolerance: number) {
  const guides: Guide[] = [];
  if (layer.rotation) return { x, y, guides };
  const others = doc.layers.filter(item => item.id !== layer.id && !item.hidden);
  const targets = (axis: "x" | "y") => {
    const size = axis === "x" ? doc.width : doc.height;
    const values = [0, size / 2, size];
    for (const item of others) {
      const start = axis === "x" ? item.x : item.y;
      const length = axis === "x" ? item.width : item.height;
      values.push(start, start + length / 2, start + length);
    }
    return values;
  };
  const apply = (axis: "x" | "y", position: number, length: number) => {
    let best: { delta: number; at: number } | null = null;
    for (const edge of [position, position + length / 2, position + length]) {
      for (const target of targets(axis)) {
        const delta = target - edge;
        if (Math.abs(delta) <= tolerance && (!best || Math.abs(delta) < Math.abs(best.delta))) best = { delta, at: target };
      }
    }
    if (!best) return position;
    guides.push({ axis, at: best.at });
    return position + best.delta;
  };
  return { x: apply("x", x, layer.width), y: apply("y", y, layer.height), guides };
}

export default function DesignCanvas({ document: doc, className = "", interactive = false, drawMode = false, selectedId, onSelect, onMultiSelect, onDrillDown, onMarqueeSelect, onLayerChange, onInteractionStart, onInteractionEnd, onGuides, onHover, onTextActivate, editingId, editingTableCell }: Props) {
  const svgRef = useRef<SVGSVGElement>(null);
  const prefix = useId().replace(/:/g, "");
  const drag = useRef<{ id: string; startX: number; startY: number; x: number; y: number; moved: boolean } | null>(null);
  const lastClick = useRef<{ x: number; y: number; time: number } | null>(null);
  const marquee = useRef<{ x0: number; y0: number; x1: number; y1: number; additive: boolean } | null>(null);
  const [marqueeRect, setMarqueeRect] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  const { colors, angle, offsets, radial } = gradientStops(doc.background);
  const gradientId = `${prefix}-bg`;

  function toCanvas(event: { clientX: number; clientY: number }) {
    const rect = svgRef.current!.getBoundingClientRect();
    const scale = rect.width / doc.width || 1;
    return { x: (event.clientX - rect.left) / scale, y: (event.clientY - rect.top) / (rect.height / doc.height || 1), scale };
  }

  function pointerDown(event: PointerEvent<SVGSVGElement>) {
    if (!interactive || drawMode) return;
    // Shift+click must reach multi-select even while another text box is being edited
    // (the editor closes the overlay as part of toggling). Plain clicks stay blocked.
    if (editingId && !event.shiftKey) return;
    const point = toCanvas(event);
    const pad = 5 / point.scale;
    // Unlocked layers win a click, but a locked layer can still be selected when it is
    // the only thing under the pointer — so it can be unlocked from the canvas toolbar.
    const hits = doc.layers.filter(layer => !layer.hidden && layerContainsPoint(layer, point.x, point.y, pad)).reverse();
    const unlocked = hits.filter(layer => !layer.locked);
    const candidates = unlocked.length ? unlocked : hits;
    if (!candidates.length) {
      // Empty canvas: start a rubber-band marquee (Canva-style). A plain click that
      // never drags deselects on release; Shift adds the swept layers instead.
      if (editingId) return;
      marquee.current = { x0: point.x, y0: point.y, x1: point.x, y1: point.y, additive: event.shiftKey };
      setMarqueeRect({ x0: point.x, y0: point.y, x1: point.x, y1: point.y });
      svgRef.current?.setPointerCapture(event.pointerId);
      lastClick.current = null;
      return;
    }
    const previous = lastClick.current;
    const samePlace = !!previous && Math.hypot(previous.x - point.x, previous.y - point.y) < 6 / point.scale && Date.now() - previous.time < 4000;
    const currentIndex = candidates.findIndex(layer => layer.id === selectedId);
    const picked = samePlace && currentIndex >= 0 && candidates.length > 1 ? candidates[(currentIndex + 1) % candidates.length] : candidates[0];
    lastClick.current = { x: point.x, y: point.y, time: Date.now() };
    // Shift + click toggles multi-select before a single-layer click claims it.
    if (event.shiftKey && onMultiSelect) { onMultiSelect(picked.id); event.preventDefault(); event.stopPropagation(); return; }
    onSelect?.(picked.id);
    event.preventDefault();
    // Locked layers select (so they can be unlocked) but never start a move.
    if (picked.locked) return;
    svgRef.current?.setPointerCapture(event.pointerId);
    onInteractionStart?.();
    drag.current = { id: picked.id, startX: event.clientX, startY: event.clientY, x: picked.x, y: picked.y, moved: false };
  }

  function pointerMove(event: PointerEvent<SVGSVGElement>) {
    if (marquee.current) {
      const point = toCanvas(event);
      marquee.current = { ...marquee.current, x1: point.x, y1: point.y };
      setMarqueeRect({ x0: marquee.current.x0, y0: marquee.current.y0, x1: point.x, y1: point.y });
      return;
    }
    const state = drag.current;
    if (!state) {
      if (interactive && !drawMode && svgRef.current) {
        const point = toCanvas(event);
        const hovered = topLayerAt(doc, point.x, point.y, 4 / point.scale);
        onHover?.(hovered?.id ?? null);
        svgRef.current.style.cursor = hovered && !hovered.locked ? "move" : "default";
      }
      return;
    }
    const layer = doc.layers.find(item => item.id === state.id);
    if (!layer) return;
    const rect = svgRef.current!.getBoundingClientRect();
    const dx = (event.clientX - state.startX) * doc.width / rect.width;
    const dy = (event.clientY - state.startY) * doc.height / rect.height;
    if (!state.moved && Math.hypot(dx, dy) < 1) return;
    state.moved = true;
    const tolerance = 6 * doc.width / rect.width;
    const snapped = event.altKey ? { x: state.x + dx, y: state.y + dy, guides: [] as Guide[] } : snapPosition(layer, state.x + dx, state.y + dy, doc, tolerance);
    onGuides?.(snapped.guides);
    onLayerChange?.(state.id, { x: Math.round(snapped.x), y: Math.round(snapped.y) });
  }

  function pointerUp() {
    if (marquee.current) {
      const m = marquee.current;
      marquee.current = null;
      setMarqueeRect(null);
      const rect = svgRef.current!.getBoundingClientRect();
      const scale = rect.width / doc.width || 1;
      const threshold = 6 / scale;
      const minX = Math.min(m.x0, m.x1), maxX = Math.max(m.x0, m.x1);
      const minY = Math.min(m.y0, m.y1), maxY = Math.max(m.y0, m.y1);
      if (maxX - minX < threshold && maxY - minY < threshold) {
        // Plain click on empty canvas: deselect (Shift+click keeps the set).
        if (!m.additive) { onSelect?.(null); onHover?.(null); }
        return;
      }
      // Rubber-band: every unlocked, visible layer whose box intersects the sweep.
      const hits = doc.layers
        .filter(layer => {
          if (layer.hidden || layer.locked) return false;
          const a = (layer.rotation || 0) * Math.PI / 180;
          const hw = layer.width / 2, hh = layer.height / 2;
          const cx = layer.x + hw, cy = layer.y + hh;
          const ex = Math.abs(Math.cos(a)) * hw + Math.abs(Math.sin(a)) * hh;
          const ey = Math.abs(Math.sin(a)) * hw + Math.abs(Math.cos(a)) * hh;
          return cx + ex >= minX && cx - ex <= maxX && cy + ey >= minY && cy - ey <= maxY;
        })
        .map(layer => layer.id);
      onMarqueeSelect?.(hits, m.additive);
      return;
    }
    if (drag.current) { onGuides?.([]); onInteractionEnd?.(); }
    drag.current = null;
  }

  function doubleClick(event: React.MouseEvent<SVGSVGElement>) {
    if (!interactive || drawMode) return;
    const point = toCanvas(event);
    const anyHit = topLayerAt(doc, point.x, point.y, 4 / point.scale);
    // Double-click a grouped layer to drill into just that member.
    if (anyHit?.groupId && anyHit.type !== "text" && onDrillDown) { onDrillDown(anyHit.id); return; }
    const hit = topLayerAt(doc, point.x, point.y, 4 / point.scale, true);
    if (hit) { onSelect?.(hit.id); onTextActivate?.(hit.id); }
  }

  return (
    <svg ref={svgRef} xmlns="http://www.w3.org/2000/svg" viewBox={`0 0 ${doc.width} ${doc.height}`} className={`design-canvas ${className}`} role="img" aria-label="Design preview" data-export-canvas={interactive ? "true" : undefined} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp} onPointerLeave={() => onHover?.(null)} onDoubleClick={doubleClick} style={{ touchAction: interactive ? "none" : "auto", background: doc.background, cursor: drawMode ? "crosshair" : undefined }}>
      {isGradient(doc.background) && <defs>{radial
        ? <radialGradient id={gradientId} cx="0.5" cy="0.5" r="0.7">{colors.map((color, index) => <stop key={index} offset={`${offsets[index]}%`} stopColor={color} />)}</radialGradient>
        : <linearGradient id={gradientId} gradientTransform={`rotate(${angle} 0.5 0.5)`}>{colors.map((color, index) => <stop key={index} offset={`${offsets[index]}%`} stopColor={color} />)}</linearGradient>}</defs>}
      <rect width={doc.width} height={doc.height} fill={isGradient(doc.background) ? `url(#${gradientId})` : doc.background} />
      {doc.layers.map(storedLayer => {
        const layer = normalizeCurvedLayer(storedLayer);
        // Hide the layer being edited so edit mode never shows the text twice
        // (canvas copy + overlay copy). The overlay is the single editable view.
        if (layer.hidden || layer.id === editingId) return null;
        const { id, type, x, y, width, height, fill, rotation = 0, opacity = 1 } = layer;
        const uid = `${prefix}-${id}`;
        const fontSize = layer.fontSize || 40;
        const anchorX = layer.align === "center" ? width / 2 : layer.align === "right" ? width : 0;
        const outlineWeight = Math.max(2, Math.min(width, height) * .055);
        const asset = shapeByKey(layer.shape);
        const painted = paint(layer, uid, width, height);
        const fillPaint = painted.fill;
        const curvedGlyphList = type === "text" && Math.abs(layer.curve || 0) >= 4 ? curvedGlyphs(layer) : null;
        const curveBox = curvedGlyphList ? curveBounds(layer, curvedGlyphList) : null;
        const fx = layer.effects;
        // Straight text is typeset word by word: CorelDRAW's justification widens word gaps
        // to the frame, Word's drop cap spans N lines, lists hang their markers in their own
        // column, and sub/superscripts carry Word's 65% size with a raised/sunk baseline.
        const typeset = type === "text" && !curvedGlyphList ? typesetText(layer) : null;
        // Eraser dabs are stored in the layer's naturalWidth × naturalHeight space and scale with width × height.
        const erasedDabs = layer.erased?.length && type !== "draw" ? layer.erased : null;
        const eraseNatW = layer.naturalWidth || width;
        const eraseNatH = layer.naturalHeight || height;
        const eraseScaleX = width / Math.max(1, eraseNatW);
        const eraseScaleY = height / Math.max(1, eraseNatH);
        const eraseBleed = Math.max(width, height, eraseNatW, eraseNatH) * 0.75;
        // Vector layers (shape, star, icon, rect, etc.) render outline with crisp mitered
        // vector strokes so sharp vertices (triangle, star points, diamond) stay razor sharp
        // instead of turning into round dilate bubbles.
        const isVectorLayer = type === "shape" || type === "star" || type === "icon" || type === "rect" || type === "ellipse" || type === "flower";
        const fxOutline = fx?.outline && fx.outline.width > 0 ? fx.outline : null;
        const hasVectorFxOutline = isVectorLayer && !!fxOutline;
        const filtered = hasEffects(fx) && !!fx && !!(
          fx.shadow || fx.glow || (!hasVectorFxOutline && fx.outline?.width) ||
          fx.blur || fx.grayscale || fx.sepia ||
          (fx.brightness !== undefined && fx.brightness !== 1) ||
          (fx.contrast !== undefined && fx.contrast !== 1) ||
          (fx.saturation !== undefined && fx.saturation !== 1)
        );
        // The miter limit matches each shape's own reach, so a point stays razor sharp right up
        // to the distance the selection frame reserves for it — and never a pixel beyond.
        const fxBleed = outlineBleed(layer);
        const miterLimit = fxOutline ? Math.max(1.05, fxBleed / fxOutline.width) : 4;
        const miterAttrs = { strokeLinejoin: "miter" as const, strokeMiterlimit: miterLimit, strokeLinecap: "butt" as const };
        const flip = fx?.flipX || fx?.flipY ? ` translate(${width / 2} ${height / 2}) scale(${fx.flipX ? -1 : 1} ${fx.flipY ? -1 : 1}) translate(${-width / 2} ${-height / 2})` : "";
        const textNode = curvedGlyphList && curveBox
          ? curvedGlyphList.map((glyph, index) => {
            const gx = glyph.x - curveBox.minX, gy = glyph.y - curveBox.minY;
            return <text key={index} x={gx} y={gy} fill={layer.textFillTransparent ? "none" : fillPaint} stroke={layer.textStrokeWidth ? (layer.textStrokeColor || layer.fill) : undefined} strokeWidth={layer.textStrokeWidth || undefined} paintOrder="stroke fill" strokeLinejoin="round" fontSize={fontSize} fontFamily={layer.fontFamily || "Arial"} fontWeight={layer.fontWeight || 400} fontStyle={layer.italic ? "italic" : "normal"} textDecoration={[layer.underline ? "underline" : "", layer.strikethrough ? "line-through" : ""].filter(Boolean).join(" ") || undefined} textAnchor="middle" transform={`rotate(${glyph.rotation} ${gx} ${gy})`} style={{ userSelect: "none" }}>{glyph.char === " " ? "\u00a0" : glyph.char}</text>;
          })
          : typeset
            ? <g style={{ userSelect: "none" }}>
              <text fill={layer.textFillTransparent ? "none" : fillPaint} stroke={layer.textStrokeWidth ? (layer.textStrokeColor || layer.fill) : undefined} strokeWidth={layer.textStrokeWidth || undefined} paintOrder="stroke fill" strokeLinejoin="round" fontSize={fontSize} fontFamily={layer.fontFamily || "Arial"} fontWeight={layer.fontWeight || 400} fontStyle={layer.italic ? "italic" : "normal"} textAnchor="start" style={{ userSelect: "none" }}>
                {typeset.lines.map((line, index) => line.runs.map((run, i) => <tspan key={`${index}-${i}`} x={run.x} y={run.y} fontSize={run.size} letterSpacing={run.letterSpacing || undefined}>{run.text}</tspan>))}
              </text>
              {typeset.dropCap && <text fill={typeset.dropCap.fill || (layer.textFillTransparent ? "none" : fillPaint)} stroke={layer.textStrokeWidth ? (layer.textStrokeColor || layer.fill) : undefined} strokeWidth={layer.textStrokeWidth || undefined} paintOrder="stroke fill" strokeLinejoin="round" fontSize={typeset.dropCap.size} fontFamily={typeset.dropCap.font || layer.fontFamily || "Arial"} fontWeight={layer.fontWeight || 400} fontStyle={layer.italic ? "italic" : "normal"} textAnchor="start" x={typeset.dropCap.x} y={typeset.dropCap.y} letterSpacing={typeset.dropCap.letterSpacing || undefined} style={{ userSelect: "none" }}>
                {typeset.dropCap.text}
              </text>}
              {/* Underline and strikethrough are typeset rules, so justified word gaps stay covered. */}
              {typeset.lines.flatMap((line, index) => line.rules.map((rule, i) => <rect key={`rule-${index}-${i}`} x={rule.x} y={rule.y} width={Math.max(0, rule.width)} height={rule.thickness} fill={layer.textFillTransparent ? (layer.textStrokeColor || layer.fill) : fillPaint} />))}
            </g>
            : null;
        return (
          <g key={id} data-layer-id={id} transform={`translate(${x} ${y}) rotate(${rotation} ${width / 2} ${height / 2})${flip}`} opacity={opacity} pointerEvents="none" filter={filtered ? `url(#${uid}-fx)` : undefined} mask={erasedDabs ? `url(#${uid}-erase)` : layer.opacityFade ? `url(#${uid}-opacity-fade)` : undefined}>
            {erasedDabs && <defs><mask id={`${uid}-erase`} maskUnits="userSpaceOnUse" x={-eraseBleed} y={-eraseBleed} width={width + eraseBleed * 2} height={height + eraseBleed * 2}>
              <rect x={-eraseBleed} y={-eraseBleed} width={width + eraseBleed * 2} height={height + eraseBleed * 2} fill="#fff" />
              <g transform={`scale(${eraseScaleX} ${eraseScaleY})`}>
                {erasedDabs.map(([ex, ey, er, strength], index) => {
                  const alpha = strength === undefined ? 1 : Math.max(0, Math.min(1, strength));
                  const shade = Math.round(255 * (1 - alpha));
                  // At full strength the dab is a solid cut-out, so the shape really disappears.
                  if (alpha >= 0.999) return <circle key={index} cx={ex} cy={ey} r={er} fill="#000" />;
                  const gid = `${uid}-erase-${index}`;
                  // Lighter passes fade from the strongest shade at the centre out to untouched.
                  return <g key={index}>
                    <radialGradient id={gid}>
                      <stop offset="35%" stopColor={`rgb(${shade},${shade},${shade})`} />
                      <stop offset="100%" stopColor="#fff" />
                    </radialGradient>
                    <circle cx={ex} cy={ey} r={er} fill={`url(#${gid})`} />
                  </g>;
                })}
              </g>
            </mask></defs>}
            {layer.opacityFade && <OpacityFadeMask layer={layer} id={`${uid}-opacity-fade`} />}
            {filtered && fx && <defs>{effectFilter(`${uid}-fx`, fx, hasVectorFxOutline)}</defs>}
            {painted.defs && <defs>{painted.defs}</defs>}
            {type === "rect" && (() => {
              const r = layer.radius || 0;
              return <>
                {hasVectorFxOutline && (
                  <rect
                    x={-fxOutline!.width}
                    y={-fxOutline!.width}
                    width={width + fxOutline!.width * 2}
                    height={height + fxOutline!.width * 2}
                    rx={r > 0 ? r + fxOutline!.width : 0}
                    fill={fxOutline!.color}
                  />
                )}
                <rect
                  x={layer.outline ? outlineWeight / 2 : 0} y={layer.outline ? outlineWeight / 2 : 0}
                  width={layer.outline ? Math.max(0, width - outlineWeight) : width} height={layer.outline ? Math.max(0, height - outlineWeight) : height}
                  rx={Math.max(0, r - (layer.outline ? outlineWeight / 2 : 0))}
                  fill={layer.outline ? "none" : fillPaint} stroke={layer.outline ? fillPaint : "none"} strokeWidth={layer.outline ? outlineWeight : 0}
                  {...miterAttrs}
                />
              </>;
            })()}
            {type === "line" && <rect width={width} height={Math.max(2, height)} fill={fillPaint} />}
            {type === "ellipse" && <>
              {hasVectorFxOutline && (
                <ellipse
                  cx={width / 2} cy={height / 2}
                  rx={width / 2 + fxOutline!.width} ry={height / 2 + fxOutline!.width}
                  fill="none" stroke={fxOutline!.color} strokeWidth={fxOutline!.width * 2}
                />
              )}
              <ellipse cx={width / 2} cy={height / 2}
                rx={Math.max(0, width / 2 - (layer.outline ? outlineWeight / 2 : 0))} ry={Math.max(0, height / 2 - (layer.outline ? outlineWeight / 2 : 0))}
                fill={layer.outline ? "none" : fillPaint} stroke={layer.outline ? fillPaint : "none"} strokeWidth={layer.outline ? outlineWeight : 0}
              />
            </>}
            {type === "star" && (() => {
              const starD = `M${width / 2} 0 Q${width * .6} ${height * .4} ${width} ${height / 2} Q${width * .6} ${height * .6} ${width / 2} ${height} Q${width * .4} ${height * .6} 0 ${height / 2} Q${width * .4} ${height * .4} ${width / 2} 0 Z`;
              return <>
                {hasVectorFxOutline && (
                  <path
                    d={starD}
                    fill="none"
                    stroke={fxOutline!.color}
                    strokeWidth={fxOutline!.width * 2}
                    {...miterAttrs}
                  />
                )}
                {layer.outline ? (() => {
                  const insetW = Math.max(0.01, (width - outlineWeight) / width);
                  const insetH = Math.max(0.01, (height - outlineWeight) / height);
                  return <g transform={`translate(${outlineWeight / 2} ${outlineWeight / 2}) scale(${insetW} ${insetH})`}>
                    <path d={starD} fill="none" stroke={fillPaint} strokeWidth={outlineWeight / insetW} {...miterAttrs} />
                  </g>;
                })() : (
                  <path d={starD} fill={fillPaint} stroke="none" strokeWidth={0} />
                )}
              </>;
            })()}
            {type === "flower" && (() => {
              const fPath = flowerPath(width, height);
              return <>
                {hasVectorFxOutline && (
                  <path d={fPath} fill="none" stroke={fxOutline!.color} strokeWidth={fxOutline!.width * 2} {...miterAttrs} />
                )}
                {layer.outline ? (() => {
                  const insetW = Math.max(0.01, (width - outlineWeight) / width);
                  const insetH = Math.max(0.01, (height - outlineWeight) / height);
                  return <g transform={`translate(${outlineWeight / 2} ${outlineWeight / 2}) scale(${insetW} ${insetH})`}>
                    <path d={fPath} fill="none" stroke={fillPaint} strokeWidth={outlineWeight / insetW} {...miterAttrs} />
                  </g>;
                })() : (
                  <path d={fPath} fill={fillPaint} stroke="none" strokeWidth={0} />
                )}
              </>;
            })()}
            {type === "shape" && asset && (() => {
              // A square with a corner radius renders as a true rounded rectangle, so the
              // Effects panel's corner-radius control works for shapes too (not rectangles only).
              const cornerRadius = Math.max(0, Math.min(layer.radius || 0, Math.min(width, height) / 2));
              if (asset.key === "square" && cornerRadius > 0) {
                return <>
                  {hasVectorFxOutline && (
                    <rect
                      x={-fxOutline!.width}
                      y={-fxOutline!.width}
                      width={width + fxOutline!.width * 2}
                      height={height + fxOutline!.width * 2}
                      rx={cornerRadius + fxOutline!.width}
                      fill={fxOutline!.color}
                    />
                  )}
                  <rect
                    x={layer.outline ? outlineWeight / 2 : 0} y={layer.outline ? outlineWeight / 2 : 0}
                    width={layer.outline ? Math.max(0, width - outlineWeight) : width} height={layer.outline ? Math.max(0, height - outlineWeight) : height}
                    rx={Math.max(0, cornerRadius - (layer.outline ? outlineWeight / 2 : 0))}
                    fill={layer.outline ? "none" : fillPaint} stroke={layer.outline ? fillPaint : "none"} strokeWidth={layer.outline ? outlineWeight : 0}
                    {...miterAttrs}
                  />
                </>;
              }
              // The path lives on a 100×100 grid. To keep the shape's outline stroke
              // strictly inside the selection frame (0..width, 0..height), we inset
              // the shape by half of strokeW within the 100×100 grid itself.
              const shapeScale = ((width / 100) + (height / 100)) / 2 || 1;
              const strokeW = Math.max(1, (outlineWeight / Math.min(width, height)) * 100);
              const inset = Math.max(0.01, (100 - strokeW) / 100);
              const offset = strokeW / 2;
              return <g transform={`scale(${width / 100} ${height / 100})`}>
                {hasVectorFxOutline && (
                  <path
                    d={asset.d}
                    fillRule={asset.evenOdd ? "evenodd" : "nonzero"}
                    fill="none"
                    stroke={fxOutline!.color}
                    strokeWidth={(fxOutline!.width * 2) / shapeScale}
                    {...miterAttrs}
                  />
                )}
                {layer.outline ? (
                  <g transform={`translate(${offset} ${offset}) scale(${inset} ${inset})`}>
                    <path
                      d={asset.d}
                      fillRule={asset.evenOdd ? "evenodd" : "nonzero"}
                      fill="none"
                      stroke={fillPaint}
                      strokeWidth={strokeW}
                      {...miterAttrs}
                    />
                  </g>
                ) : (
                  <path d={asset.d} fillRule={asset.evenOdd ? "evenodd" : "nonzero"} fill={fillPaint} stroke="none" strokeWidth={0} />
                )}
              </g>;
            })()}
            {type === "icon" && layer.path && (() => {
              // Icon paths live on a 24×24 grid. Inset by strokeW in the 24×24 grid
              // so outline icons never spill outside their selection frame.
              const iconScale = ((width / 24) + (height / 24)) / 2 || 1;
              const strokeW = Math.max(0.6, (outlineWeight / Math.min(width, height)) * 24);
              const inset = Math.max(0.01, (24 - strokeW) / 24);
              const offset = strokeW / 2;
              return <g transform={`scale(${width / 24} ${height / 24})`}>
                {hasVectorFxOutline && (
                  <path
                    d={layer.path}
                    fill="none"
                    stroke={fxOutline!.color}
                    strokeWidth={(fxOutline!.width * 2) / iconScale + 2}
                    strokeLinejoin="round"
                    strokeLinecap="round"
                  />
                )}
                {layer.outline ? (
                  <g transform={`translate(${offset} ${offset}) scale(${inset} ${inset})`}>
                    <path
                      d={layer.path}
                      fill="none"
                      stroke={fillPaint}
                      strokeWidth={strokeW}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </g>
                ) : (
                  <path
                    d={layer.path}
                    fill={fillPaint}
                    stroke="none"
                    strokeWidth={0}
                  />
                )}
              </g>;
            })()}
            {type === "stroke" && strokeContent({ ...layer, fill: fillPaint === layer.fill ? layer.fill : fillPaint }, width, height)}
            {type === "table" && tableContent(layer, width, height, uid, editingTableCell?.layerId === layer.id ? editingTableCell : null)}
            {type === "draw" && layer.d && <g transform={`scale(${width / (layer.naturalWidth || width)} ${height / (layer.naturalHeight || height)})`}>{layer.erased?.length ? <defs><mask id={`${uid}-erase`} maskUnits="userSpaceOnUse" x={-5000} y={-5000} width={10000} height={10000}><rect x={-5000} y={-5000} width={10000} height={10000} fill="#fff" />{layer.erased.map(([ex, ey, er], i) => <circle key={i} cx={ex} cy={ey} r={er} fill="#000" />)}</mask></defs> : null}<path d={layer.d} fill="none" stroke={fillPaint} strokeWidth={layer.strokeWidth ?? 6} strokeLinecap="round" strokeLinejoin="round" mask={layer.erased?.length ? `url(#${uid}-erase)` : undefined} /></g>}
            {type === "pattern" && <><defs><pattern id={uid} width={layer.tile || 60} height={layer.tile || 60} patternUnits="userSpaceOnUse">{patternTile(layer.pattern || "dots", fillPaint, layer.tile || 60)}</pattern></defs><rect width={width} height={height} fill={`url(#${uid})`} /></>}
            {type === "image" && photoContent(layer, uid, width, height)}
            {type === "text" && textNode}
          </g>
        );
      })}
      {marqueeRect && <rect x={Math.min(marqueeRect.x0, marqueeRect.x1)} y={Math.min(marqueeRect.y0, marqueeRect.y1)} width={Math.abs(marqueeRect.x1 - marqueeRect.x0)} height={Math.abs(marqueeRect.y1 - marqueeRect.y0)} fill="#7c4de0" fillOpacity={0.08} stroke="#7c4de0" strokeWidth={1.5 / (svgRef.current ? (svgRef.current.getBoundingClientRect().width / doc.width || 1) : 1)} pointerEvents="none" />}
    </svg>
  );
}

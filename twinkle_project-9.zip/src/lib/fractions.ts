import { setScriptRange, shiftScriptRanges, type ScriptKind, type ScriptRange } from "@/lib/script-text";

export const VULGAR_FRACTIONS: Record<string, string> = {
  "1/2": "½",
  "1/3": "⅓",
  "2/3": "⅔",
  "1/4": "¼",
  "3/4": "¾",
  "1/5": "⅕",
  "2/5": "⅖",
  "3/5": "⅗",
  "4/5": "⅘",
  "1/6": "⅙",
  "5/6": "⅚",
  "1/8": "⅛",
  "3/8": "⅜",
  "5/8": "⅝",
  "7/8": "⅞",
};

export const FRACTION_GALLERY = [
  { symbol: "½", num: "1", den: "2", label: "1/2" },
  { symbol: "⅓", num: "1", den: "3", label: "1/3" },
  { symbol: "⅔", num: "2", den: "3", label: "2/3" },
  { symbol: "¼", num: "1", den: "4", label: "1/4" },
  { symbol: "¾", num: "3", den: "4", label: "3/4" },
  { symbol: "⅕", num: "1", den: "5", label: "1/5" },
  { symbol: "⅖", num: "2", den: "5", label: "2/5" },
  { symbol: "⅗", num: "3", den: "5", label: "3/5" },
  { symbol: "⅘", num: "4", den: "5", label: "4/5" },
  { symbol: "⅙", num: "1", den: "6", label: "1/6" },
  { symbol: "⅚", num: "5", den: "6", label: "5/6" },
  { symbol: "⅛", num: "1", den: "8", label: "1/8" },
  { symbol: "⅜", num: "3", den: "8", label: "3/8" },
  { symbol: "⅝", num: "5", den: "8", label: "5/8" },
  { symbol: "⅞", num: "7", den: "8", label: "7/8" },
] as const;

const SUP_DIGITS: Record<string, string> = {
  "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
  "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹",
};

const SUB_DIGITS: Record<string, string> = {
  "0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄",
  "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉",
};

/** Formats numerator and denominator into a single vulgar fraction or diagonal fraction (e.g. 5/16 -> ⁵⁄₁₆). */
export function formatFraction(num: string | number, den: string | number): string {
  const nStr = String(num).trim();
  const dStr = String(den).trim();
  const key = `${nStr}/${dStr}`;
  if (VULGAR_FRACTIONS[key]) return VULGAR_FRACTIONS[key];
  if (/^\d+$/.test(nStr) && /^\d+$/.test(dStr)) {
    const supN = nStr.split("").map(c => SUP_DIGITS[c] || c).join("");
    const subD = dStr.split("").map(c => SUB_DIGITS[c] || c).join("");
    return `${supN}⁄${subD}`;
  }
  return key;
}

/**
 * Word & CorelDRAW Smart Fraction typing:
 * - `^1/2` or `^3/4` -> `½` with superscript (e.g. 1+2^1/2 -> 1+2¹⁄₂)
 * - `v1/2` or `_1/2` -> `½` with subscript (e.g. CHv1/2 -> CH₁⸝₂)
 * - `1/2 ` or `3/4 ` -> `½ ` or `¾ ` (normal vulgar fraction on space)
 */
export function autoFormatFractionInText(
  rawText: string,
  cursor: number,
  currentRanges?: ScriptRange[]
): { text: string; cursor: number; ranges?: ScriptRange[] } | null {
  if (cursor <= 0) return null;
  const beforeCaret = rawText.slice(0, cursor);
  const afterCaret = rawText.slice(cursor);

  // 1) Superscript fraction: ^1/2 or ^(\d+)/(\d+) (e.g. 1+2^1/2 -> 1+2½ as super)
  const superMatch = /\^(\d+)\/(\d+)$/.exec(beforeCaret);
  if (superMatch) {
    const num = superMatch[1], den = superMatch[2];
    const frac = formatFraction(num, den);
    const matchStart = superMatch.index;
    const newText = beforeCaret.slice(0, matchStart) + frac + afterCaret;
    const newCursor = matchStart + frac.length;

    let updatedRanges = shiftScriptRanges(rawText, newText, currentRanges) || [];
    updatedRanges = setScriptRange(newText, updatedRanges, matchStart, matchStart + frac.length, "super");
    return { text: newText, cursor: newCursor, ranges: updatedRanges.length ? updatedRanges : undefined };
  }

  // 2) Subscript fraction: v1/2 or _1/2 or [v_](\d+)/(\d+) (e.g. CHv1/2 or CH_1/2 -> CH½ as sub)
  const subMatch = /[v_](\d+)\/(\d+)$/.exec(beforeCaret);
  if (subMatch) {
    const num = subMatch[1], den = subMatch[2];
    const frac = formatFraction(num, den);
    const matchStart = subMatch.index;
    const newText = beforeCaret.slice(0, matchStart) + frac + afterCaret;
    const newCursor = matchStart + frac.length;

    let updatedRanges = shiftScriptRanges(rawText, newText, currentRanges) || [];
    updatedRanges = setScriptRange(newText, updatedRanges, matchStart, matchStart + frac.length, "sub");
    return { text: newText, cursor: newCursor, ranges: updatedRanges.length ? updatedRanges : undefined };
  }

  // 3) Plain auto-fraction on trailing space: e.g. "1/2 " -> "½ "
  const plainMatch = /(?:^|[\s+\-*()=])(\d+)\/(\d+)\s$/.exec(beforeCaret);
  if (plainMatch) {
    const num = plainMatch[1], den = plainMatch[2];
    const frac = formatFraction(num, den);
    const fullMatched = plainMatch[0];
    const fracOffsetInMatch = fullMatched.indexOf(`${num}/${den} `);
    if (fracOffsetInMatch >= 0) {
      const matchStart = plainMatch.index + fracOffsetInMatch;
      const replacement = `${frac} `;
      const newText = beforeCaret.slice(0, matchStart) + replacement + afterCaret;
      const newCursor = matchStart + replacement.length;
      const updatedRanges = shiftScriptRanges(rawText, newText, currentRanges);
      return { text: newText, cursor: newCursor, ranges: updatedRanges };
    }
  }

  return null;
}

/** Inserts or replaces selected text with a fraction in normal, superscript or subscript position. */
export function insertFractionIntoText(
  text: string,
  start: number,
  end: number,
  fraction: string,
  mode: "normal" | "super" | "sub",
  currentRanges?: ScriptRange[]
): { text: string; start: number; end: number; ranges?: ScriptRange[] } {
  const s = Math.max(0, Math.min(text.length, Math.min(start, end)));
  const e = Math.max(0, Math.min(text.length, Math.max(start, end)));
  const newText = text.slice(0, s) + fraction + text.slice(e);
  const fracStart = s;
  const fracEnd = s + fraction.length;

  let ranges = shiftScriptRanges(text, newText, currentRanges) || [];
  if (mode === "super") {
    ranges = setScriptRange(newText, ranges, fracStart, fracEnd, "super");
  } else if (mode === "sub") {
    ranges = setScriptRange(newText, ranges, fracStart, fracEnd, "sub");
  } else {
    ranges = setScriptRange(newText, ranges, fracStart, fracEnd, null);
  }
  return { text: newText, start: fracEnd, end: fracEnd, ranges: ranges.length ? ranges : undefined };
}

/** Converts any plain "a/b" occurrences in the text into typographic fractions. */
export function convertTextFractions(
  text: string,
  currentRanges?: ScriptRange[]
): { text: string; ranges?: ScriptRange[]; count: number } {
  let count = 0;
  const replaced = text.replace(/(\d+)\/(\d+)/g, (_match, num, den) => {
    count++;
    return formatFraction(num, den);
  });
  const ranges = shiftScriptRanges(text, replaced, currentRanges);
  return { text: replaced, ranges, count };
}

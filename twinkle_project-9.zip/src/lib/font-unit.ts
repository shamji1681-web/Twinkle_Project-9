import { useSyncExternalStore } from "react";

/**
 * The measurement unit (pt / px / mm) shown next to font and line sizes.
 * One shared value, so the font toolbar and the line properties never disagree.
 */
const STORAGE_KEY = "creato-font-unit";
export const FONT_UNITS = ["pt", "px", "mm"] as const;
export type FontUnit = typeof FONT_UNITS[number];

function readStored(): FontUnit {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return FONT_UNITS.includes(stored as FontUnit) ? (stored as FontUnit) : "pt";
  } catch {
    return "pt";
  }
}

let current: FontUnit = readStored();
const listeners = new Set<() => void>();

export function setFontUnit(unit: FontUnit) {
  if (unit === current) return;
  current = unit;
  try { localStorage.setItem(STORAGE_KEY, unit); } catch { /* storage may be unavailable */ }
  listeners.forEach(listener => listener());
}

const subscribe = (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; };

export function useFontUnit(): [FontUnit, (unit: FontUnit) => void] {
  const unit = useSyncExternalStore(subscribe, () => current, () => "pt" as FontUnit);
  return [unit, setFontUnit];
}

// Conversion functions
export const ptToPx = (pt: number) => pt / 0.75;
export const pxToPt = (px: number) => px * 0.75;
export const mmToPx = (mm: number) => mm * 96 / 25.4;
export const pxToMm = (px: number) => px * 25.4 / 96;

export function toDisplayFontUnit(value: number, unit: FontUnit): number {
  switch (unit) {
    case "pt": return pxToPt(value);
    case "mm": return pxToMm(value);
    case "px": return value;
    default: return value;
  }
}

export function fromDisplayFontUnit(value: number, unit: FontUnit): number {
  switch (unit) {
    case "pt": return ptToPx(value);
    case "mm": return mmToPx(value);
    case "px": return value;
    default: return value;
  }
}

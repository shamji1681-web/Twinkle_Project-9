export interface FadePoint { x: number; y: number }

/** Points are relative to the layer, so resizing never detaches the fade. */
export interface OpacityFade {
  start: FadePoint;
  end: FadePoint;
  startOpacity: number;
  endOpacity: number;
  midpoint: number;
}

export type FadeDirection = "right" | "left" | "down" | "up";
export interface FadeSize { width: number; height: number }

export const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const round = (value: number) => Math.round(value * 10000) / 10000;
export const clampFadePoint = (point: FadePoint): FadePoint => ({ x: round(clamp(point.x, -2, 3)), y: round(clamp(point.y, -2, 3)) });

export function defaultOpacityFade(direction: FadeDirection = "right"): OpacityFade {
  const points: Record<FadeDirection, [FadePoint, FadePoint]> = {
    right: [{ x: 0.35, y: 0.5 }, { x: 0.95, y: 0.5 }],
    left: [{ x: 0.65, y: 0.5 }, { x: 0.05, y: 0.5 }],
    down: [{ x: 0.5, y: 0.35 }, { x: 0.5, y: 0.95 }],
    up: [{ x: 0.5, y: 0.65 }, { x: 0.5, y: 0.05 }],
  };
  return { start: { ...points[direction][0] }, end: { ...points[direction][1] }, startOpacity: 1, endOpacity: 0, midpoint: 0.5 };
}

export function isOpacityFade(value: unknown): value is OpacityFade {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const fade = value as Partial<OpacityFade>;
  const numberIn = (n: unknown, lo: number, hi: number) => typeof n === "number" && Number.isFinite(n) && n >= lo && n <= hi;
  const point = (p: unknown): p is FadePoint => !!p && typeof p === "object" && numberIn((p as FadePoint).x, -2, 3) && numberIn((p as FadePoint).y, -2, 3);
  if (!point(fade.start) || !point(fade.end)) return false;
  if (Math.hypot(fade.start.x - fade.end.x, fade.start.y - fade.end.y) < 0.001) return false;
  return numberIn(fade.startOpacity, 0, 1) && numberIn(fade.endOpacity, 0, 1) && numberIn(fade.midpoint, 0.05, 0.95);
}

/** Clockwise degrees from left-to-right, measured in the element's real aspect ratio. */
export function fadeAngle(fade: OpacityFade, size: FadeSize): number {
  const radians = Math.atan2((fade.end.y - fade.start.y) * size.height, (fade.end.x - fade.start.x) * size.width);
  return (Math.round(radians * 180 / Math.PI) + 360) % 360;
}

/** Rotate the axis around its centre, keeping the transition length constant. */
export function rotateOpacityFade(fade: OpacityFade, angle: number, size: FadeSize): OpacityFade {
  const cx = (fade.start.x + fade.end.x) * size.width / 2;
  const cy = (fade.start.y + fade.end.y) * size.height / 2;
  const half = Math.hypot((fade.end.x - fade.start.x) * size.width, (fade.end.y - fade.start.y) * size.height) / 2;
  const rad = angle * Math.PI / 180;
  const dx = Math.cos(rad) * half, dy = Math.sin(rad) * half;
  return {
    ...fade,
    start: clampFadePoint({ x: (cx - dx) / size.width, y: (cy - dy) / size.height }),
    end: clampFadePoint({ x: (cx + dx) / size.width, y: (cy + dy) / size.height }),
  };
}

/** Shared stops for SVG rendering, thumbnails and exports. No coloured overlay. */
export function opacityFadeStops(fade: OpacityFade) {
  return [
    { offset: 0, alpha: fade.startOpacity },
    { offset: fade.midpoint, alpha: (fade.startOpacity + fade.endOpacity) / 2 },
    { offset: 1, alpha: fade.endOpacity },
  ];
}

import { useSyncExternalStore } from "react";
import { fontsSnapshot, subscribeFonts, type CustomFont } from "@/lib/fonts";

/** Reactive list of the user's uploaded fonts. */
export function useCustomFonts(): CustomFont[] {
  return useSyncExternalStore(subscribeFonts, fontsSnapshot, fontsSnapshot);
}

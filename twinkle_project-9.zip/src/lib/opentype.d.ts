declare module "opentype.js" {
  export interface PathOptions { kerning?: boolean }
  export interface GlyphPath { toPathData(decimalPlaces?: number): string }
  export interface Glyph {
    getPath(x: number, y: number, fontSize: number): GlyphPath;
    advanceWidth: number;
  }
  export interface Font {
    unitsPerEm: number;
    getPath(text: string, x: number, y: number, fontSize: number, options?: PathOptions): GlyphPath;
    getAdvanceWidth(text: string, fontSize: number, options?: PathOptions): number;
    charToGlyph(char: string): Glyph;
  }
  export function parse(buffer: ArrayBuffer): Font;
}

import { useSyncExternalStore } from "react";
import type { LengthUnit } from "@/lib/table";

/**
 * The measurement unit (mm / px / in) shown next to element sizes.
 * One shared value, so the canvas toolbar and the table cell fields never disagree.
 */
const STORAGE_KEY = "creato-length-unit";
export const LENGTH_UNITS: LengthUnit[] = ["mm", "px", "in"];

function readStored(): LengthUnit {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return LENGTH_UNITS.includes(stored as LengthUnit) ? (stored as LengthUnit) : "mm";
  } catch {
    return "mm";
  }
}

let current: LengthUnit = readStored();
const listeners = new Set<() => void>();

export function setLengthUnit(unit: LengthUnit) {
  if (unit === current) return;
  current = unit;
  try { localStorage.setItem(STORAGE_KEY, unit); } catch { /* storage may be unavailable */ }
  listeners.forEach(listener => listener());
}

const subscribe = (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; };

export function useLengthUnit(): [LengthUnit, (unit: LengthUnit) => void] {
  const unit = useSyncExternalStore(subscribe, () => current, () => "mm" as LengthUnit);
  return [unit, setLengthUnit];
}
